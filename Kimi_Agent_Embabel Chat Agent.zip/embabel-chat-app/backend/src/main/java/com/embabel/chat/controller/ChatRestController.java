package com.embabel.chat.controller;

import com.embabel.chat.model.*;
import com.embabel.chat.service.ChatSessionService;
import com.embabel.chat.agent.DocumentIngestionAgent;
import com.embabel.chat.vault.VaultService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;

/**
 * Chat REST Controller
 * 
 * Provides REST API endpoints for chat operations:
 * - Session management
 * - Message history
 * - Document management
 * - System status
 */
@Slf4j
@RestController
@RequestMapping("/api/chat")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
public class ChatRestController {

    private final ChatSessionService sessionService;
    private final DocumentIngestionAgent documentAgent;
    private final VaultService vaultService;
    
    /**
     * Create a new chat session
     */
    @PostMapping("/sessions")
    public ResponseEntity<ChatSession> createSession(
            @RequestParam(required = false) String userId,
            @RequestParam(required = false) String title) {
        
        log.info("Creating new session for user: {}", userId);
        ChatSession session = sessionService.createSession(userId, title);
        return ResponseEntity.ok(session);
    }
    
    /**
     * Get session by ID
     */
    @GetMapping("/sessions/{sessionId}")
    public ResponseEntity<ChatSession> getSession(@PathVariable String sessionId) {
        ChatSession session = sessionService.getSession(sessionId);
        if (session == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(session);
    }
    
    /**
     * Get session messages
     */
    @GetMapping("/sessions/{sessionId}/messages")
    public ResponseEntity<List<ChatMessage>> getSessionMessages(
            @PathVariable String sessionId,
            @RequestParam(defaultValue = "50") int limit) {
        
        List<ChatMessage> messages = sessionService.getRecentMessages(sessionId, limit);
        return ResponseEntity.ok(messages);
    }
    
    /**
     * Get user's sessions
     */
    @GetMapping("/sessions")
    public ResponseEntity<List<ChatSession>> getUserSessions(
            @RequestParam(required = false) String userId) {
        
        List<ChatSession> sessions = sessionService.getUserSessions(userId);
        return ResponseEntity.ok(sessions);
    }
    
    /**
     * Delete a session
     */
    @DeleteMapping("/sessions/{sessionId}")
    public ResponseEntity<Void> deleteSession(@PathVariable String sessionId) {
        boolean deleted = sessionService.deleteSession(sessionId);
        if (deleted) {
            return ResponseEntity.ok().build();
        }
        return ResponseEntity.notFound().build();
    }
    
    /**
     * Update session title
     */
    @PutMapping("/sessions/{sessionId}/title")
    public ResponseEntity<Void> updateSessionTitle(
            @PathVariable String sessionId,
            @RequestBody String title) {
        
        sessionService.updateSessionTitle(sessionId, title);
        return ResponseEntity.ok().build();
    }
    
    /**
     * Send a chat message (non-streaming)
     */
    @PostMapping("/sessions/{sessionId}/messages")
    public ResponseEntity<ChatResponse> sendMessage(
            @PathVariable String sessionId,
            @RequestBody ChatRequest request) {
        
        log.info("Received message for session {}: {}", sessionId, request.getMessage());
        
        // Add user message
        ChatMessage userMessage = ChatMessage.userMessage(sessionId, request.getMessage());
        sessionService.addMessage(sessionId, userMessage);
        
        // For now, return a simple response
        // In a full implementation, this would invoke the orchestrator agent
        String responseText = generateSimpleResponse(request.getMessage());
        
        ChatMessage assistantMessage = ChatMessage.assistantMessage(sessionId, responseText);
        sessionService.addMessage(sessionId, assistantMessage);
        
        ChatResponse response = ChatResponse.contentComplete(sessionId, responseText);
        return ResponseEntity.ok(response);
    }
    
    /**
     * Get all documents
     */
    @GetMapping("/documents")
    public ResponseEntity<List<DocumentIngestionAgent.DocumentInfo>> getDocuments() {
        List<DocumentIngestionAgent.DocumentInfo> documents = documentAgent.listDocuments(null);
        return ResponseEntity.ok(documents);
    }
    
    /**
     * Ingest a document
     */
    @PostMapping("/documents")
    public ResponseEntity<DocumentIngestionAgent.IngestionResult> ingestDocument(
            @RequestParam String filePath) {
        
        log.info("Ingesting document: {}", filePath);
        
        DocumentIngestionAgent.IngestionRequest request = 
                new DocumentIngestionAgent.IngestionRequest(filePath, null, null);
        
        // Note: In a real implementation, you'd use the AgentPlatform to run the agent
        // For demo, we return a mock result
        DocumentIngestionAgent.IngestionResult result = new DocumentIngestionAgent.IngestionResult(
                UUID.randomUUID().toString(),
                true,
                "Document ingested successfully (simulated)",
                10,
                new DocumentIngestionAgent.DocumentInfo(
                        UUID.randomUUID().toString(),
                        filePath.substring(filePath.lastIndexOf('/') + 1),
                        filePath,
                        "application/pdf",
                        1024,
                        10,
                        java.time.Instant.now(),
                        DocumentIngestionAgent.DocumentStatus.INGESTED,
                        null
                )
        );
        
        return ResponseEntity.ok(result);
    }
    
    /**
     * Search documents
     */
    @GetMapping("/documents/search")
    public ResponseEntity<List<DocumentIngestionAgent.DocumentSearchResult>> searchDocuments(
            @RequestParam String query) {
        
        log.info("Searching documents for: {}", query);
        
        // Note: In a real implementation, you'd use the AgentPlatform to run the agent
        // For demo, we return mock results
        List<DocumentIngestionAgent.DocumentSearchResult> results = List.of(
                new DocumentIngestionAgent.DocumentSearchResult(
                        "doc-1",
                        "Embabel is a sophisticated agent framework for the JVM...",
                        0.95,
                        Map.of("source", "Embabel Documentation.pdf")
                ),
                new DocumentIngestionAgent.DocumentSearchResult(
                        "doc-2",
                        "The framework uses GOAP (Goal-Oriented Action Planning)...",
                        0.87,
                        Map.of("source", "Embabel-Developer-Documentation.pdf")
                )
        );
        
        return ResponseEntity.ok(results);
    }
    
    /**
     * Get document statistics
     */
    @GetMapping("/documents/statistics")
    public ResponseEntity<DocumentIngestionAgent.DocumentStatistics> getDocumentStatistics() {
        // Note: In a real implementation, you'd use the AgentPlatform to run the agent
        DocumentIngestionAgent.DocumentStatistics stats = new DocumentIngestionAgent.DocumentStatistics(
                5,  // total
                4,  // ingested
                1,  // failed
                50, // chunks
                45  // indexed
        );
        
        return ResponseEntity.ok(stats);
    }
    
    /**
     * Get system status
     */
    @GetMapping("/status")
    public ResponseEntity<Map<String, Object>> getStatus() {
        Map<String, Object> status = new HashMap<>();
        
        // Session statistics
        status.put("sessions", sessionService.getStatistics());
        
        // Vault status
        status.put("vault", vaultService.getVaultStatus());
        
        // System info
        status.put("system", Map.of(
                "version", "1.0.0",
                "embabelVersion", "0.3.4",
                "timestamp", java.time.Instant.now()
        ));
        
        return ResponseEntity.ok(status);
    }
    
    /**
     * Get available visualization types
     */
    @GetMapping("/visualizations/types")
    public ResponseEntity<List<Map<String, String>>> getVisualizationTypes() {
        List<Map<String, String>> types = List.of(
                Map.of("id", "pie", "name", "Pie Chart", "description", "Show proportions"),
                Map.of("id", "bar", "name", "Bar Chart", "description", "Compare values"),
                Map.of("id", "line", "name", "Line Chart", "description", "Show trends"),
                Map.of("id", "doughnut", "name", "Doughnut Chart", "description", "Show distribution")
        );
        
        return ResponseEntity.ok(types);
    }
    
    /**
     * Generate a simple response for demo purposes
     */
    private String generateSimpleResponse(String message) {
        String lowerMessage = message.toLowerCase();
        
        if (lowerMessage.contains("hello") || lowerMessage.contains("hi")) {
            return "Hello! I'm your AI assistant powered by Embabel 0.3.4. I can help you with:\n\n" +
                   "- **Answering questions** about Embabel and your documents\n" +
                   "- **Data analysis** and insights\n" +
                   "- **Visualizations** (pie charts, bar charts, etc.)\n" +
                   "- **Document Q&A** using RAG\n\n" +
                   "How can I assist you today?";
        }
        
        if (lowerMessage.contains("embabel")) {
            return "**Embabel** is a sophisticated agent framework for the JVM that enables building AI-powered applications.\n\n" +
                   "## Key Features:\n\n" +
                   "- **GOAP Planning**: Goal-Oriented Action Planning for intelligent agent orchestration\n" +
                   "- **Multi-Agent Coordination**: Multiple specialized agents working together\n" +
                   "- **Type Safety**: Full compile-time type checking with Java/Kotlin\n" +
                   "- **Spring Integration**: Native Spring Boot support\n" +
                   "- **RAG Support**: Built-in document ingestion and retrieval\n\n" +
                   "Would you like to know more about any specific feature?";
        }
        
        if (lowerMessage.contains("chart") || lowerMessage.contains("graph") || lowerMessage.contains("pie") || lowerMessage.contains("bar")) {
            return "I can create various visualizations for you! Here are the supported chart types:\n\n" +
                   "- **Pie Chart**: Best for showing proportions and percentages\n" +
                   "- **Bar Chart**: Great for comparing values across categories\n" +
                   "- **Line Chart**: Perfect for showing trends over time\n" +
                   "- **Doughnut Chart**: Similar to pie but with a center hole\n\n" +
                   "Just describe what data you'd like to visualize, and I'll create it for you!";
        }
        
        if (lowerMessage.contains("document") || lowerMessage.contains("pdf") || lowerMessage.contains("rag")) {
            return "I have access to the following Embabel documentation files:\n\n" +
                   "1. **Embabel Documentation.pdf** - Overview and core concepts\n" +
                   "2. **Embabel-API-Documentation.md** - Complete API reference\n" +
                   "3. **Embabel-Developer-Documentation.pdf** - Developer guide\n" +
                   "4. **Embabel-vs-SpringAI-LangGraph.pdf** - Framework comparison\n\n" +
                   "Feel free to ask me anything about Embabel's features, API, or architecture!";
        }
        
        return "Thank you for your message! I'm processing it through my multi-agent system powered by Embabel.\n\n" +
               "I can help you with:\n" +
               "- Questions about Embabel framework\n" +
               "- Data analysis and visualizations\n" +
               "- Document Q&A\n\n" +
               "What would you like to explore?";
    }
}
