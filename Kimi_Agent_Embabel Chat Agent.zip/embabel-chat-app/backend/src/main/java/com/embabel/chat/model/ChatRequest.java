package com.embabel.chat.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Map;

/**
 * Chat Request DTO
 * Represents a chat message request from the client.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ChatRequest {
    
    /**
     * Message content
     */
    @NotBlank(message = "Message content is required")
    private String message;
    
    /**
     * Conversation ID (null for new conversation)
     */
    private String conversationId;
    
    /**
     * User ID (optional, for authenticated users)
     */
    private String userId;
    
    /**
     * Request type
     */
    @NotNull
    @Builder.Default
    private RequestType type = RequestType.CHAT;
    
    /**
     * Whether to stream the response
     */
    @Builder.Default
    private boolean stream = true;
    
    /**
     * Whether to show thinking process
     */
    @Builder.Default
    private boolean showThinking = true;
    
    /**
     * Requested visualization type (if any)
     */
    private VisualizationType visualization;
    
    /**
     * Document IDs for context (RAG)
     */
    private java.util.List<String> documentIds;
    
    /**
     * Additional context/parameters
     */
    private Map<String, Object> context;
    
    public enum RequestType {
        CHAT,           // Regular chat message
        DOCUMENT_QUERY, // Query about documents
        VISUALIZATION,  // Request for visualization
        SYSTEM          // System command
    }
    
    public enum VisualizationType {
        AUTO,           // Auto-detect based on query
        PIE_CHART,      // Pie chart
        BAR_CHART,      // Bar chart
        LINE_CHART,     // Line chart
        TABLE           // Data table
    }
    
    /**
     * Create a simple chat request
     */
    public static ChatRequest of(String message) {
        return ChatRequest.builder()
                .message(message)
                .type(RequestType.CHAT)
                .stream(true)
                .showThinking(true)
                .build();
    }
    
    /**
     * Create a chat request with conversation ID
     */
    public static ChatRequest of(String message, String conversationId) {
        return ChatRequest.builder()
                .message(message)
                .conversationId(conversationId)
                .type(RequestType.CHAT)
                .stream(true)
                .showThinking(true)
                .build();
    }
    
    /**
     * Create a document query request
     */
    public static ChatRequest documentQuery(String message, java.util.List<String> documentIds) {
        return ChatRequest.builder()
                .message(message)
                .type(RequestType.DOCUMENT_QUERY)
                .documentIds(documentIds)
                .stream(true)
                .showThinking(true)
                .build();
    }
    
    /**
     * Create a visualization request
     */
    public static ChatRequest visualization(String message, VisualizationType type) {
        return ChatRequest.builder()
                .message(message)
                .type(RequestType.VISUALIZATION)
                .visualization(type)
                .stream(true)
                .showThinking(true)
                .build();
    }
}
