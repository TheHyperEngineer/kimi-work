package com.embabel.chat.agent;

import com.embabel.agent.api.annotation.Action;
import com.embabel.agent.api.annotation.Agent;
import com.embabel.agent.api.common.OperationContext;
import com.embabel.chat.model.VisualizationData;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Data Analysis Agent
 * 
 * Analyzes data from user queries and extracts insights.
 * Can work with:
 * - Data embedded in the query
 * - Data from documents
 * - Simulated data for demonstration
 * 
 * Outputs structured analysis that can be used for visualizations.
 */
@Slf4j
@Component
@Agent(description = "Agent that analyzes data and extracts insights for visualization")
public class DataAnalysisAgent {
    
    /**
     * Analysis request
     */
    public record AnalysisRequest(
            String query,
            List<DataPoint> dataPoints,
            String dataSource
    ) {}
    
    /**
     * Data point
     */
    public record DataPoint(
            String label,
            double value,
            String category,
            Map<String, Object> metadata
    ) {}
    
    /**
     * Analysis result
     */
    public record AnalysisResult(
            List<String> insights,
            List<String> trends,
            List<String> recommendations,
            Map<String, Double> statistics,
            List<DataPoint> processedData,
            VisualizationData.ChartType suggestedChartType
    ) {}
    
    /**
     * Action: Extract data from query
     */
    @Action(description = "Extract data points from user query")
    public List<DataPoint> extractDataFromQuery(String query, OperationContext context) {
        log.info("Extracting data from query: {}", query);
        
        List<DataPoint> dataPoints = new ArrayList<>();
        
        // Try to extract numerical data from the query
        // Pattern: "label: value" or "label - value" or just numbers
        Pattern pattern = Pattern.compile("(\\w+)\\s*[:\\-]?\\s*(\\d+(?:\\.\\d+)?)");
        Matcher matcher = pattern.matcher(query);
        
        while (matcher.find()) {
            String label = matcher.group(1);
            double value = Double.parseDouble(matcher.group(2));
            dataPoints.add(new DataPoint(label, value, "extracted", null));
        }
        
        // If no data found, try to use LLM to extract or generate sample data
        if (dataPoints.isEmpty()) {
            dataPoints = extractDataWithLlm(query, context);
        }
        
        log.info("Extracted {} data points", dataPoints.size());
        return dataPoints;
    }
    
    /**
     * Action: Analyze data
     */
    @Action(description = "Analyze data and extract insights")
    public AnalysisResult analyzeData(AnalysisRequest request, OperationContext context) {
        log.info("Analyzing data from source: {}", request.dataSource());
        
        List<DataPoint> data = request.dataPoints();
        
        if (data == null || data.isEmpty()) {
            return new AnalysisResult(
                    List.of("No data available for analysis"),
                    Collections.emptyList(),
                    List.of("Please provide data to analyze"),
                    Collections.emptyMap(),
                    Collections.emptyList(),
                    null
            );
        }
        
        // Calculate statistics
        Map<String, Double> statistics = calculateStatistics(data);
        
        // Generate insights using LLM
        List<String> insights = generateInsights(request, statistics, context);
        
        // Identify trends
        List<String> trends = identifyTrends(data, context);
        
        // Generate recommendations
        List<String> recommendations = generateRecommendations(data, insights, context);
        
        // Suggest chart type
        VisualizationData.ChartType suggestedChart = suggestChartType(data, request.query());
        
        return new AnalysisResult(
                insights,
                trends,
                recommendations,
                statistics,
                data,
                suggestedChart
        );
    }
    
    /**
     * Action: Generate sample data for demonstration
     */
    @Action(description = "Generate sample data for demonstration purposes")
    public List<DataPoint> generateSampleData(String dataType, OperationContext context) {
        log.info("Generating sample data for type: {}", dataType);
        
        return switch (dataType.toLowerCase()) {
            case "sales" -> List.of(
                    new DataPoint("January", 45000, "sales", null),
                    new DataPoint("February", 52000, "sales", null),
                    new DataPoint("March", 48000, "sales", null),
                    new DataPoint("April", 61000, "sales", null),
                    new DataPoint("May", 58000, "sales", null),
                    new DataPoint("June", 67000, "sales", null)
            );
            case "marketshare" -> List.of(
                    new DataPoint("Product A", 35, "market_share", null),
                    new DataPoint("Product B", 28, "market_share", null),
                    new DataPoint("Product C", 22, "market_share", null),
                    new DataPoint("Product D", 15, "market_share", null)
            );
            case "performance" -> List.of(
                    new DataPoint("Team Alpha", 92, "performance", null),
                    new DataPoint("Team Beta", 87, "performance", null),
                    new DataPoint("Team Gamma", 95, "performance", null),
                    new DataPoint("Team Delta", 78, "performance", null)
            );
            case "satisfaction" -> List.of(
                    new DataPoint("Very Satisfied", 45, "satisfaction", null),
                    new DataPoint("Satisfied", 32, "satisfaction", null),
                    new DataPoint("Neutral", 15, "satisfaction", null),
                    new DataPoint("Dissatisfied", 8, "satisfaction", null)
            );
            default -> List.of(
                    new DataPoint("Category 1", 25, "default", null),
                    new DataPoint("Category 2", 35, "default", null),
                    new DataPoint("Category 3", 20, "default", null),
                    new DataPoint("Category 4", 20, "default", null)
            );
        };
    }
    
    /**
     * Action: Compare datasets
     */
    @Action(description = "Compare two or more datasets")
    public ComparisonResult compareDatasets(List<List<DataPoint>> datasets, List<String> labels, OperationContext context) {
        log.info("Comparing {} datasets", datasets.size());
        
        if (datasets.size() < 2) {
            return new ComparisonResult(
                    false,
                    "Need at least 2 datasets to compare",
                    Collections.emptyList(),
                    Collections.emptyMap()
            );
        }
        
        // Calculate comparison metrics
        List<String> comparisons = new ArrayList<>();
        Map<String, Double> metrics = new HashMap<>();
        
        for (int i = 0; i < datasets.size(); i++) {
            List<DataPoint> dataset = datasets.get(i);
            double sum = dataset.stream().mapToDouble(DataPoint::value).sum();
            double avg = dataset.stream().mapToDouble(DataPoint::value).average().orElse(0);
            
            metrics.put(labels.get(i) + "_total", sum);
            metrics.put(labels.get(i) + "_average", avg);
        }
        
        // Use LLM for qualitative comparison
        String comparisonText = context.ai()
                .withLlmByRole("analysis")
                .generateText(
                        """
                        Compare these datasets:
                        %s
                        Provide key differences and similarities.
                        """.formatted(formatDatasetsForComparison(datasets, labels))
                );
        
        comparisons.addAll(Arrays.asList(comparisonText.split("\\n")));
        
        return new ComparisonResult(
                true,
                "Comparison completed",
                comparisons,
                metrics
        );
    }
    
    // Supporting records
    public record ComparisonResult(
            boolean success,
            String message,
            List<String> comparisons,
            Map<String, Double> metrics
    ) {}
    
    // Helper methods
    private List<DataPoint> extractDataWithLlm(String query, OperationContext context) {
        // Use LLM to understand what data might be relevant
        String dataDescription = context.ai()
                .withLlmByRole("fast")
                .generateText(
                        """
                        The user is asking about: "%s"
                        What kind of data would be relevant to answer this question?
                        Describe the data categories and approximate values.
                        """.formatted(query)
                );
        
        // For demo, generate sample data based on query keywords
        if (query.toLowerCase().contains("sales") || query.toLowerCase().contains("revenue")) {
            return generateSampleData("sales", context);
        } else if (query.toLowerCase().contains("market") || query.toLowerCase().contains("share")) {
            return generateSampleData("marketshare", context);
        } else if (query.toLowerCase().contains("performance") || query.toLowerCase().contains("team")) {
            return generateSampleData("performance", context);
        } else if (query.toLowerCase().contains("satisfaction") || query.toLowerCase().contains("survey")) {
            return generateSampleData("satisfaction", context);
        }
        
        return generateSampleData("default", context);
    }
    
    private Map<String, Double> calculateStatistics(List<DataPoint> data) {
        double sum = data.stream().mapToDouble(DataPoint::value).sum();
        double avg = data.stream().mapToDouble(DataPoint::value).average().orElse(0);
        double max = data.stream().mapToDouble(DataPoint::value).max().orElse(0);
        double min = data.stream().mapToDouble(DataPoint::value).min().orElse(0);
        
        // Calculate standard deviation
        double variance = data.stream()
                .mapToDouble(d -> Math.pow(d.value() - avg, 2))
                .average()
                .orElse(0);
        double stdDev = Math.sqrt(variance);
        
        return Map.of(
                "sum", sum,
                "average", avg,
                "max", max,
                "min", min,
                "stdDev", stdDev,
                "count", (double) data.size()
        );
    }
    
    private List<String> generateInsights(AnalysisRequest request, Map<String, Double> statistics, OperationContext context) {
        String insightsText = context.ai()
                .withLlmByRole("analysis")
                .generateText(
                        """
                        Analyze this data and provide 3-5 key insights:
                        Query: %s
                        Statistics: %s
                        Data points: %s
                        """.formatted(
                                request.query(),
                                statistics,
                                request.dataPoints()
                        )
                );
        
        return Arrays.stream(insightsText.split("\\n"))
                .filter(s -> !s.trim().isEmpty())
                .toList();
    }
    
    private List<String> identifyTrends(List<DataPoint> data, OperationContext context) {
        // Simple trend detection
        List<String> trends = new ArrayList<>();
        
        if (data.size() < 2) {
            return trends;
        }
        
        // Check for increasing/decreasing trend
        boolean increasing = true;
        boolean decreasing = true;
        
        for (int i = 1; i < data.size(); i++) {
            if (data.get(i).value() < data.get(i - 1).value()) {
                increasing = false;
            }
            if (data.get(i).value() > data.get(i - 1).value()) {
                decreasing = false;
            }
        }
        
        if (increasing) {
            trends.add("Data shows an increasing trend");
        } else if (decreasing) {
            trends.add("Data shows a decreasing trend");
        } else {
            trends.add("Data shows fluctuating values");
        }
        
        // Add trend based on average
        double avg = data.stream().mapToDouble(DataPoint::value).average().orElse(0);
        double latest = data.get(data.size() - 1).value();
        
        if (latest > avg * 1.1) {
            trends.add("Latest value is above average");
        } else if (latest < avg * 0.9) {
            trends.add("Latest value is below average");
        }
        
        return trends;
    }
    
    private List<String> generateRecommendations(List<DataPoint> data, List<String> insights, OperationContext context) {
        return context.ai()
                .withLlmByRole("analysis")
                .createObject(
                        """
                        Based on this data analysis, provide 2-3 actionable recommendations:
                        Insights: %s
                        Data: %s
                        """.formatted(insights, data),
                        Recommendations.class
                ).recommendations();
    }
    
    private VisualizationData.ChartType suggestChartType(List<DataPoint> data, String query) {
        // Determine best chart type based on data and query
        String lowerQuery = query.toLowerCase();
        
        if (lowerQuery.contains("pie") || lowerQuery.contains("distribution") || lowerQuery.contains("percentage")) {
            return VisualizationData.ChartType.PIE;
        }
        
        if (lowerQuery.contains("bar") || lowerQuery.contains("compare") || lowerQuery.contains("comparison")) {
            return VisualizationData.ChartType.BAR;
        }
        
        if (lowerQuery.contains("line") || lowerQuery.contains("trend") || lowerQuery.contains("over time")) {
            return VisualizationData.ChartType.LINE;
        }
        
        // Default based on data characteristics
        if (data.size() <= 5) {
            return VisualizationData.ChartType.PIE;
        } else if (data.size() <= 10) {
            return VisualizationData.ChartType.BAR;
        } else {
            return VisualizationData.ChartType.LINE;
        }
    }
    
    private String formatDatasetsForComparison(List<List<DataPoint>> datasets, List<String> labels) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < datasets.size(); i++) {
            sb.append(labels.get(i)).append(": ");
            sb.append(datasets.get(i)).append("\n");
        }
        return sb.toString();
    }
    
    // Record for LLM response
    public record Recommendations(List<String> recommendations) {}
}
