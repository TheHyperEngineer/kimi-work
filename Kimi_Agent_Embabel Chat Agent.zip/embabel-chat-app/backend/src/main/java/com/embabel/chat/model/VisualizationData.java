package com.embabel.chat.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Map;

/**
 * Visualization Data Model
 * Represents chart/graph data for data visualization in the chat.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class VisualizationData {
    
    private String id;
    private ChartType type;
    private String title;
    private String description;
    private String source;
    
    // Chart data
    private List<DataPoint> data;
    private List<DataSeries> series;
    
    // Axis configuration
    private AxisConfig xAxis;
    private AxisConfig yAxis;
    
    // Chart options
    private ChartOptions options;
    
    // Raw data for export
    private Map<String, Object> rawData;
    
    public enum ChartType {
        PIE,            // Pie chart
        DOUGHNUT,       // Doughnut chart
        BAR,            // Bar chart
        HORIZONTAL_BAR, // Horizontal bar chart
        LINE,           // Line chart
        AREA,           // Area chart
        SCATTER,        // Scatter plot
        RADAR,          // Radar chart
        POLAR_AREA      // Polar area chart
    }
    
    /**
     * Single data point
     */
    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class DataPoint {
        private String label;
        private double value;
        private String color;
        private Map<String, Object> metadata;
        
        public static DataPoint of(String label, double value) {
            return DataPoint.builder()
                    .label(label)
                    .value(value)
                    .build();
        }
        
        public static DataPoint of(String label, double value, String color) {
            return DataPoint.builder()
                    .label(label)
                    .value(value)
                    .color(color)
                    .build();
        }
    }
    
    /**
     * Data series for multi-series charts
     */
    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class DataSeries {
        private String name;
        private String color;
        private List<Double> data;
        private Map<String, Object> metadata;
    }
    
    /**
     * Axis configuration
     */
    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class AxisConfig {
        private String title;
        private String type;  // category, linear, logarithmic, time
        private List<String> categories;
        private Double min;
        private Double max;
        private boolean gridLines;
    }
    
    /**
     * Chart options
     */
    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class ChartOptions {
        private boolean legend;
        private String legendPosition;  // top, bottom, left, right
        private boolean tooltips;
        private boolean animation;
        private boolean responsive;
        private int height;
        private int width;
        private Map<String, Object> additionalOptions;
    }
    
    /**
     * Create a pie chart visualization
     */
    public static VisualizationData pieChart(String title, String description, List<DataPoint> data) {
        return VisualizationData.builder()
                .id(java.util.UUID.randomUUID().toString())
                .type(ChartType.PIE)
                .title(title)
                .description(description)
                .data(data)
                .options(ChartOptions.builder()
                        .legend(true)
                        .legendPosition("bottom")
                        .tooltips(true)
                        .animation(true)
                        .responsive(true)
                        .build())
                .build();
    }
    
    /**
     * Create a bar chart visualization
     */
    public static VisualizationData barChart(String title, String description, 
                                              List<String> labels, List<DataSeries> series) {
        return VisualizationData.builder()
                .id(java.util.UUID.randomUUID().toString())
                .type(ChartType.BAR)
                .title(title)
                .description(description)
                .series(series)
                .xAxis(AxisConfig.builder()
                        .title("Categories")
                        .type("category")
                        .categories(labels)
                        .build())
                .yAxis(AxisConfig.builder()
                        .title("Values")
                        .type("linear")
                        .gridLines(true)
                        .build())
                .options(ChartOptions.builder()
                        .legend(true)
                        .legendPosition("top")
                        .tooltips(true)
                        .animation(true)
                        .responsive(true)
                        .build())
                .build();
    }
    
    /**
     * Create a simple bar chart from data points
     */
    public static VisualizationData simpleBarChart(String title, String description, List<DataPoint> data) {
        List<String> labels = data.stream()
                .map(DataPoint::getLabel)
                .toList();
        
        List<Double> values = data.stream()
                .map(DataPoint::getValue)
                .toList();
        
        DataSeries series = DataSeries.builder()
                .name("Values")
                .data(values)
                .build();
        
        return barChart(title, description, labels, List.of(series));
    }
}
