package com.embabel.chat.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Chat Session Model
 * Represents a conversation session with message history and context.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ChatSession {
    
    private String id;
    private String userId;
    private String title;
    private SessionStatus status;
    
    @Builder.Default
    private List<ChatMessage> messages = new CopyOnWriteArrayList<>();
    
    // Session timing
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", timezone = "UTC")
    private Instant createdAt;
    
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", timezone = "UTC")
    private Instant lastActivityAt;
    
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", timezone = "UTC")
    private Instant endedAt;
    
    // Session context (for agent blackboard)
    private Map<String, Object> context;
    
    // Document context for RAG
    private List<String> documentIds;
    
    // Session metadata
    private SessionMetadata metadata;
    
    // Agent process tracking
    private String currentAgentProcessId;
    private AgentStatus agentStatus;
    
    public enum SessionStatus {
        ACTIVE,         // Session is active
        PAUSED,         // Session is paused
        ENDED,          // Session has ended
        EXPIRED         // Session has expired
    }
    
    public enum AgentStatus {
        IDLE,           // No agent running
        THINKING,       // Thinking agent is running
        PLANNING,       // Planning agent is running
        EXECUTING,      // Executing the plan
        RESPONDING,     // Response agent is generating
        TOOL_EXECUTING  // Tool is being executed
    }
    
    /**
     * Session metadata
     */
    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class SessionMetadata {
        private String userAgent;
        private String ipAddress;
        private String source;  // web, api, etc.
        private Map<String, Object> customData;
    }
    
    /**
     * Create a new chat session
     */
    public static ChatSession create(String userId, String title) {
        Instant now = Instant.now();
        return ChatSession.builder()
                .id(UUID.randomUUID().toString())
                .userId(userId)
                .title(title != null ? title : "New Conversation")
                .status(SessionStatus.ACTIVE)
                .messages(new CopyOnWriteArrayList<>())
                .createdAt(now)
                .lastActivityAt(now)
                .documentIds(new ArrayList<>())
                .agentStatus(AgentStatus.IDLE)
                .build();
    }
    
    /**
     * Add a message to the session
     */
    public void addMessage(ChatMessage message) {
        this.messages.add(message);
        this.lastActivityAt = Instant.now();
    }
    
    /**
     * Update the last activity timestamp
     */
    public void touch() {
        this.lastActivityAt = Instant.now();
    }
    
    /**
     * End the session
     */
    public void end() {
        this.status = SessionStatus.ENDED;
        this.endedAt = Instant.now();
        this.agentStatus = AgentStatus.IDLE;
    }
    
    /**
     * Get the message count
     */
    public int getMessageCount() {
        return this.messages.size();
    }
    
    /**
     * Get the last message
     */
    public ChatMessage getLastMessage() {
        if (messages.isEmpty()) {
            return null;
        }
        return messages.get(messages.size() - 1);
    }
    
    /**
     * Check if session is expired based on timeout
     */
    public boolean isExpired(long timeoutMinutes) {
        if (lastActivityAt == null) {
            return false;
        }
        return Instant.now().isAfter(lastActivityAt.plusSeconds(timeoutMinutes * 60));
    }
    
    /**
     * Update agent status
     */
    public void setAgentStatus(AgentStatus status) {
        this.agentStatus = status;
        this.lastActivityAt = Instant.now();
    }
    
    /**
     * Add document to session context
     */
    public void addDocument(String documentId) {
        if (this.documentIds == null) {
            this.documentIds = new ArrayList<>();
        }
        this.documentIds.add(documentId);
        this.lastActivityAt = Instant.now();
    }
    
    /**
     * Get context value
     */
    public Object getContextValue(String key) {
        if (this.context == null) {
            return null;
        }
        return this.context.get(key);
    }
    
    /**
     * Set context value
     */
    public void setContextValue(String key, Object value) {
        if (this.context == null) {
            this.context = new java.util.concurrent.ConcurrentHashMap<>();
        }
        this.context.put(key, value);
    }
    
    /**
     * Get recent messages for context window
     */
    public List<ChatMessage> getRecentMessages(int count) {
        if (messages.size() <= count) {
            return new ArrayList<>(messages);
        }
        return new ArrayList<>(messages.subList(messages.size() - count, messages.size()));
    }
    
    /**
     * Get conversation history as formatted string for LLM context
     */
    public String getFormattedHistory(int maxMessages) {
        StringBuilder sb = new StringBuilder();
        List<ChatMessage> recentMessages = getRecentMessages(maxMessages);
        
        for (ChatMessage msg : recentMessages) {
            if (msg.getRole() == ChatMessage.MessageRole.USER) {
                sb.append("User: ").append(msg.getContent()).append("\n");
            } else if (msg.getRole() == ChatMessage.MessageRole.ASSISTANT) {
                sb.append("Assistant: ").append(msg.getContent()).append("\n");
            }
        }
        
        return sb.toString();
    }
}
