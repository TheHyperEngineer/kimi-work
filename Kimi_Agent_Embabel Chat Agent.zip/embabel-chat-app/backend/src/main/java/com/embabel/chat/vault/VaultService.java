package com.embabel.chat.vault;

import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicReference;

/**
 * Vault Service
 * 
 * Simulates a secure vault for managing LLM API keys and other secrets.
 * In a production environment, this would integrate with HashiCorp Vault,
 * AWS Secrets Manager, Azure Key Vault, or similar.
 * 
 * Features:
 * - Secure API key storage and retrieval
 * - Automatic key rotation
 * - Access logging
 * - Fallback to environment variables
 */
@Slf4j
@Service
public class VaultService {

    @Value("${vault.mock-mode:true}")
    private boolean mockMode;
    
    @Value("${vault.refresh-interval-minutes:60}")
    private long refreshIntervalMinutes;
    
    // In-memory vault storage (simulated)
    private final Map<String, SecretEntry> vaultStore = new ConcurrentHashMap<>();
    
    // API key cache
    private final AtomicReference<ApiKeyCache> apiKeyCache = new AtomicReference<>();
    
    // Access audit log
    private final Map<String, AccessLog> accessLogs = new ConcurrentHashMap<>();
    
    /**
     * Secret entry in vault
     */
    public record SecretEntry(
            String key,
            String value,
            String version,
            Instant createdAt,
            Instant expiresAt,
            Map<String, String> metadata
    ) {}
    
    /**
     * API Key cache entry
     */
    public record ApiKeyCache(
            String openAiKey,
            String anthropicKey,
            String googleKey,
            Instant cachedAt,
            Instant expiresAt
    ) {}
    
    /**
     * Access log entry
     */
    public record AccessLog(
            String secretKey,
            Instant accessedAt,
            String serviceName,
            boolean success
    ) {}
    
    /**
     * Initialize the vault service
     */
    @PostConstruct
    public void initialize() {
        log.info("Initializing Vault Service (mock-mode: {})...", mockMode);
        
        if (mockMode) {
            initializeMockVault();
        }
        
        // Initial API key load
        refreshApiKeys();
        
        log.info("Vault Service initialized successfully");
    }
    
    /**
     * Initialize mock vault with demo keys
     */
    private void initializeMockVault() {
        log.info("Initializing mock vault with demo secrets...");
        
        // Get keys from environment or use demo keys
        String openAiKey = System.getenv("OPENAI_API_KEY");
        String anthropicKey = System.getenv("ANTHROPIC_API_KEY");
        String googleKey = System.getenv("GOOGLE_API_KEY");
        
        // Store in vault
        storeSecret("llm/openai/api-key", 
                openAiKey != null ? openAiKey : "sk-demo-openai-key", 
                Map.of("provider", "openai", "type", "api-key"));
        
        storeSecret("llm/anthropic/api-key", 
                anthropicKey != null ? anthropicKey : "sk-demo-anthropic-key", 
                Map.of("provider", "anthropic", "type", "api-key"));
        
        storeSecret("llm/google/api-key", 
                googleKey != null ? googleKey : "demo-google-key", 
                Map.of("provider", "google", "type", "api-key"));
        
        // Store additional configuration
        storeSecret("app/jwt-secret", 
                "demo-jwt-secret-key-for-development-only", 
                Map.of("type", "jwt", "purpose", "authentication"));
        
        log.info("Mock vault initialized with {} secrets", vaultStore.size());
    }
    
    /**
     * Store a secret in the vault
     */
    public void storeSecret(String key, String value, Map<String, String> metadata) {
        String version = generateVersion();
        SecretEntry entry = new SecretEntry(
                key,
                value,
                version,
                Instant.now(),
                Instant.now().plusSeconds(90 * 24 * 60 * 60), // 90 days expiry
                metadata
        );
        vaultStore.put(key, entry);
        log.debug("Stored secret: {} (version: {})", key, version);
    }
    
    /**
     * Retrieve a secret from the vault
     */
    public String getSecret(String key) {
        logAccess(key, "VaultService");
        
        SecretEntry entry = vaultStore.get(key);
        if (entry == null) {
            log.warn("Secret not found in vault: {}", key);
            return null;
        }
        
        // Check expiry
        if (entry.expiresAt().isBefore(Instant.now())) {
            log.warn("Secret has expired: {}", key);
            return null;
        }
        
        return entry.value();
    }
    
    /**
     * Get OpenAI API key
     */
    public String getOpenAiApiKey() {
        ApiKeyCache cache = apiKeyCache.get();
        if (cache != null && cache.expiresAt().isAfter(Instant.now())) {
            return cache.openAiKey();
        }
        
        // Refresh and return
        refreshApiKeys();
        cache = apiKeyCache.get();
        return cache != null ? cache.openAiKey() : null;
    }
    
    /**
     * Get Anthropic API key
     */
    public String getAnthropicApiKey() {
        ApiKeyCache cache = apiKeyCache.get();
        if (cache != null && cache.expiresAt().isAfter(Instant.now())) {
            return cache.anthropicKey();
        }
        
        refreshApiKeys();
        cache = apiKeyCache.get();
        return cache != null ? cache.anthropicKey() : null;
    }
    
    /**
     * Get Google API key
     */
    public String getGoogleApiKey() {
        ApiKeyCache cache = apiKeyCache.get();
        if (cache != null && cache.expiresAt().isAfter(Instant.now())) {
            return cache.googleKey();
        }
        
        refreshApiKeys();
        cache = apiKeyCache.get();
        return cache != null ? cache.googleKey() : null;
    }
    
    /**
     * Refresh API keys from vault
     */
    @Scheduled(fixedDelayString = "${vault.refresh-interval-minutes:60}00000")
    public void refreshApiKeys() {
        log.info("Refreshing API keys from vault...");
        
        String openAiKey = getSecret("llm/openai/api-key");
        String anthropicKey = getSecret("llm/anthropic/api-key");
        String googleKey = getSecret("llm/google/api-key");
        
        // Fallback to environment variables
        if (openAiKey == null || openAiKey.contains("demo")) {
            openAiKey = System.getenv().getOrDefault("OPENAI_API_KEY", "sk-demo-key");
        }
        if (anthropicKey == null || anthropicKey.contains("demo")) {
            anthropicKey = System.getenv().getOrDefault("ANTHROPIC_API_KEY", "sk-demo-key");
        }
        if (googleKey == null || googleKey.contains("demo")) {
            googleKey = System.getenv().getOrDefault("GOOGLE_API_KEY", "demo-key");
        }
        
        ApiKeyCache newCache = new ApiKeyCache(
                maskKey(openAiKey),
                maskKey(anthropicKey),
                maskKey(googleKey),
                Instant.now(),
                Instant.now().plusSeconds(refreshIntervalMinutes * 60)
        );
        
        apiKeyCache.set(newCache);
        log.info("API keys refreshed successfully");
    }
    
    /**
     * Log access to a secret
     */
    private void logAccess(String secretKey, String serviceName) {
        AccessLog logEntry = new AccessLog(
                secretKey,
                Instant.now(),
                serviceName,
                true
        );
        accessLogs.put(secretKey + "-" + System.currentTimeMillis(), logEntry);
    }
    
    /**
     * Generate a version string
     */
    private String generateVersion() {
        return "v" + System.currentTimeMillis();
    }
    
    /**
     * Mask a key for logging
     */
    private String maskKey(String key) {
        if (key == null || key.length() < 8) {
            return "***";
        }
        return key.substring(0, 4) + "..." + key.substring(key.length() - 4);
    }
    
    /**
     * Get vault status
     */
    public Map<String, Object> getVaultStatus() {
        return Map.of(
                "mockMode", mockMode,
                "secretCount", vaultStore.size(),
                "lastRefresh", apiKeyCache.get() != null ? apiKeyCache.get().cachedAt() : null,
                "nextRefresh", apiKeyCache.get() != null ? apiKeyCache.get().expiresAt() : null
        );
    }
    
    /**
     * Rotate a secret (simulated)
     */
    public boolean rotateSecret(String key) {
        log.info("Rotating secret: {}", key);
        SecretEntry entry = vaultStore.get(key);
        if (entry == null) {
            return false;
        }
        
        // In a real implementation, this would generate a new key
        // For demo, we just update the version and expiry
        storeSecret(key, entry.value(), entry.metadata());
        return true;
    }
}
