package com.embabel.chat.agent;

import com.embabel.agent.api.annotation.Action;
import com.embabel.agent.api.annotation.Agent;
import com.embabel.agent.api.annotation.AchievesGoal;
import com.embabel.agent.api.common.OperationContext;
import com.embabel.chat.model.VisualizationData;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.*;

/**
 * Visualization Agent
 * 
 * Creates charts and graphs for data visualization.
 * Supports:
 * - Pie charts
 * - Bar charts (vertical and horizontal)
 * - Line charts
 * - Doughnut charts
 * 
 * Works with data from DataAnalysisAgent or directly from queries.
 */
@Slf4j
@Component
@Agent(description = "Agent that creates charts and graphs for data visualization")
public class VisualizationAgent {
    
    // Color palette for charts
    private static final List<String> COLOR_PALETTE = List.of(
            "#FF6384", "#36A2EB", "#FFCE56", "#4BC0C0", "#9966FF",
            "#FF9F40", "#FF6384", "#C9CBCF", "#4BC0C0", "#FF6384"
    );
    
    /**
     * Visualization request
     */
    public record VisualizationRequest(
            String title,
            String description,
            List<DataAnalysisAgent.DataPoint> data,
            VisualizationData.ChartType preferredType,
            Map<String, Object> options
    ) {}
    
    /**
     * Action: Create visualization
     */
    @AchievesGoal(description = "Create appropriate chart or graph for data")
    @Action(description = "Create visualization based on data and preferences")
    public VisualizationData createVisualization(VisualizationRequest request, OperationContext context) {
        log.info("Creating visualization: {} with type: {}", request.title(), request.preferredType());
        
        // Determine chart type
        VisualizationData.ChartType chartType = determineChartType(request);
        
        // Create visualization based on type
        return switch (chartType) {
            case PIE, DOUGHNUT -> createPieChart(request, chartType);
            case BAR, HORIZONTAL_BAR -> createBarChart(request, chartType);
            case LINE, AREA -> createLineChart(request, chartType);
            default -> createDefaultChart(request);
        };
    }
    
    /**
     * Action: Create pie chart
     */
    @Action(description = "Create a pie chart visualization")
    public VisualizationData createPieChart(VisualizationRequest request, VisualizationData.ChartType type) {
        List<VisualizationData.DataPoint> dataPoints = convertToVisualizationPoints(request.data());
        
        return VisualizationData.builder()
                .id(UUID.randomUUID().toString())
                .type(type != null ? type : VisualizationData.ChartType.PIE)
                .title(request.title())
                .description(request.description())
                .data(dataPoints)
                .options(VisualizationData.ChartOptions.builder()
                        .legend(true)
                        .legendPosition("bottom")
                        .tooltips(true)
                        .animation(true)
                        .responsive(true)
                        .height(400)
                        .build())
                .build();
    }
    
    /**
     * Action: Create bar chart
     */
    @Action(description = "Create a bar chart visualization")
    public VisualizationData createBarChart(VisualizationRequest request, VisualizationData.ChartType type) {
        List<String> labels = request.data().stream()
                .map(DataAnalysisAgent.DataPoint::label)
                .toList();
        
        List<Double> values = request.data().stream()
                .map(DataAnalysisAgent.DataPoint::value)
                .toList();
        
        VisualizationData.DataSeries series = VisualizationData.DataSeries.builder()
                .name("Values")
                .data(values)
                .color(COLOR_PALETTE.get(0))
                .build();
        
        boolean isHorizontal = type == VisualizationData.ChartType.HORIZONTAL_BAR;
        
        return VisualizationData.builder()
                .id(UUID.randomUUID().toString())
                .type(VisualizationData.ChartType.BAR)
                .title(request.title())
                .description(request.description())
                .series(List.of(series))
                .xAxis(VisualizationData.AxisConfig.builder()
                        .title(isHorizontal ? "Values" : "Categories")
                        .type(isHorizontal ? "linear" : "category")
                        .categories(isHorizontal ? null : labels)
                        .gridLines(true)
                        .build())
                .yAxis(VisualizationData.AxisConfig.builder()
                        .title(isHorizontal ? "Categories" : "Values")
                        .type(isHorizontal ? "category" : "linear")
                        .categories(isHorizontal ? labels : null)
                        .gridLines(true)
                        .build())
                .options(VisualizationData.ChartOptions.builder()
                        .legend(true)
                        .legendPosition("top")
                        .tooltips(true)
                        .animation(true)
                        .responsive(true)
                        .height(400)
                        .build())
                .build();
    }
    
    /**
     * Action: Create line chart
     */
    @Action(description = "Create a line chart visualization")
    public VisualizationData createLineChart(VisualizationRequest request, VisualizationData.ChartType type) {
        List<String> labels = request.data().stream()
                .map(DataAnalysisAgent.DataPoint::label)
                .toList();
        
        List<Double> values = request.data().stream()
                .map(DataAnalysisAgent.DataPoint::value)
                .toList();
        
        VisualizationData.DataSeries series = VisualizationData.DataSeries.builder()
                .name("Trend")
                .data(values)
                .color(COLOR_PALETTE.get(1))
                .build();
        
        return VisualizationData.builder()
                .id(UUID.randomUUID().toString())
                .type(type != null ? type : VisualizationData.ChartType.LINE)
                .title(request.title())
                .description(request.description())
                .series(List.of(series))
                .xAxis(VisualizationData.AxisConfig.builder()
                        .title("X Axis")
                        .type("category")
                        .categories(labels)
                        .gridLines(true)
                        .build())
                .yAxis(VisualizationData.AxisConfig.builder()
                        .title("Values")
                        .type("linear")
                        .gridLines(true)
                        .build())
                .options(VisualizationData.ChartOptions.builder()
                        .legend(true)
                        .legendPosition("top")
                        .tooltips(true)
                        .animation(true)
                        .responsive(true)
                        .height(400)
                        .build())
                .build();
    }
    
    /**
     * Action: Create multi-series chart
     */
    @Action(description = "Create a multi-series chart for comparing multiple datasets")
    public VisualizationData createMultiSeriesChart(
            String title,
            String description,
            List<String> labels,
            List<VisualizationData.DataSeries> series,
            OperationContext context) {
        
        return VisualizationData.builder()
                .id(UUID.randomUUID().toString())
                .type(VisualizationData.ChartType.BAR)
                .title(title)
                .description(description)
                .series(series)
                .xAxis(VisualizationData.AxisConfig.builder()
                        .title("Categories")
                        .type("category")
                        .categories(labels)
                        .gridLines(true)
                        .build())
                .yAxis(VisualizationData.AxisConfig.builder()
                        .title("Values")
                        .type("linear")
                        .gridLines(true)
                        .build())
                .options(VisualizationData.ChartOptions.builder()
                        .legend(true)
                        .legendPosition("top")
                        .tooltips(true)
                        .animation(true)
                        .responsive(true)
                        .height(400)
                        .build())
                .build();
    }
    
    /**
     * Action: Create visualization from natural language query
     */
    @Action(description = "Create visualization based on natural language description")
    public VisualizationData createFromDescription(String description, OperationContext context) {
        log.info("Creating visualization from description: {}", description);
        
        // Use LLM to understand what visualization is needed
        VisualizationIntent intent = context.ai()
                .withLlmByRole("analysis")
                .createObject(
                        """
                        Analyze this visualization request and extract:
                        1. Chart type (pie, bar, line, etc.)
                        2. Title
                        3. Data categories and values
                        
                        Request: "%s"
                        """.formatted(description),
                        VisualizationIntent.class
                );
        
        // Generate sample data based on intent
        List<DataAnalysisAgent.DataPoint> data = generateDataFromIntent(intent);
        
        VisualizationRequest request = new VisualizationRequest(
                intent.title(),
                description,
                data,
                VisualizationData.ChartType.valueOf(intent.chartType().toUpperCase()),
                null
        );
        
        return createVisualization(request, context);
    }
    
    /**
     * Action: Get available chart types
     */
    @Action(description = "Get list of available chart types")
    public List<ChartTypeInfo> getAvailableChartTypes(OperationContext context) {
        return List.of(
                new ChartTypeInfo("pie", "Pie Chart", "Best for showing proportions and percentages", 
                        List.of("market share", "distribution", "composition")),
                new ChartTypeInfo("bar", "Bar Chart", "Best for comparing values across categories", 
                        List.of("comparison", "ranking", "values")),
                new ChartTypeInfo("line", "Line Chart", "Best for showing trends over time", 
                        List.of("trends", "time series", "progression")),
                new ChartTypeInfo("doughnut", "Doughnut Chart", "Similar to pie but with center hole", 
                        List.of("proportions", "distribution")),
                new ChartTypeInfo("horizontalBar", "Horizontal Bar Chart", "Bar chart with horizontal orientation", 
                        List.of("long labels", "ranking"))
        );
    }
    
    // Supporting records
    public record ChartTypeInfo(
            String id,
            String name,
            String description,
            List<String> bestFor
    ) {}
    
    public record VisualizationIntent(
            String chartType,
            String title,
            List<DataPointIntent> dataPoints
    ) {}
    
    public record DataPointIntent(
            String label,
            double value
    ) {}
    
    // Helper methods
    private VisualizationData.ChartType determineChartType(VisualizationRequest request) {
        if (request.preferredType() != null) {
            return request.preferredType();
        }
        
        // Default based on data size
        int dataSize = request.data() != null ? request.data().size() : 0;
        
        if (dataSize <= 5) {
            return VisualizationData.ChartType.PIE;
        } else if (dataSize <= 10) {
            return VisualizationData.ChartType.BAR;
        } else {
            return VisualizationData.ChartType.LINE;
        }
    }
    
    private List<VisualizationData.DataPoint> convertToVisualizationPoints(List<DataAnalysisAgent.DataPoint> data) {
        List<VisualizationData.DataPoint> points = new ArrayList<>();
        
        for (int i = 0; i < data.size(); i++) {
            DataAnalysisAgent.DataPoint dp = data.get(i);
            points.add(VisualizationData.DataPoint.builder()
                    .label(dp.label())
                    .value(dp.value())
                    .color(COLOR_PALETTE.get(i % COLOR_PALETTE.size()))
                    .build());
        }
        
        return points;
    }
    
    private VisualizationData createDefaultChart(VisualizationRequest request) {
        return createBarChart(request, VisualizationData.ChartType.BAR);
    }
    
    private List<DataAnalysisAgent.DataPoint> generateDataFromIntent(VisualizationIntent intent) {
        if (intent.dataPoints() != null && !intent.dataPoints().isEmpty()) {
            return intent.dataPoints().stream()
                    .map(dp -> new DataAnalysisAgent.DataPoint(dp.label(), dp.value(), "generated", null))
                    .toList();
        }
        
        // Default sample data
        return List.of(
                new DataAnalysisAgent.DataPoint("A", 30, "sample", null),
                new DataAnalysisAgent.DataPoint("B", 25, "sample", null),
                new DataAnalysisAgent.DataPoint("C", 20, "sample", null),
                new DataAnalysisAgent.DataPoint("D", 15, "sample", null),
                new DataAnalysisAgent.DataPoint("E", 10, "sample", null)
        );
    }
}
