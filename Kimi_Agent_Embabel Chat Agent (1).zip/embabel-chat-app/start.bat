@echo off
REM Embabel Chat Application - Quick Start Script for Windows
REM This script starts both the backend and frontend servers

echo =======================================
echo   Embabel Chat Application Starter
echo =======================================
echo.

REM Check prerequisites
echo Checking prerequisites...

java -version >nul 2>&1
if errorlevel 1 (
    echo Error: Java is not installed
    echo Please install Java 21 or higher: https://adoptium.net/
    exit /b 1
)

mvn -version >nul 2>&1
if errorlevel 1 (
    echo Error: Maven is not installed
    echo Please install Maven: https://maven.apache.org/download.cgi
    exit /b 1
)

node -v >nul 2>&1
if errorlevel 1 (
    echo Error: Node.js is not installed
    echo Please install Node.js 18 or higher: https://nodejs.org/
    exit /b 1
)

echo All prerequisites met!
echo.

REM Get script directory
cd /d "%~dp0"

REM Start Backend
echo Starting Backend Server...
cd backend

REM Check if Maven wrapper exists
if exist "mvnw.cmd" (
    set MVN_CMD=mvnw.cmd
) else (
    set MVN_CMD=mvn
)

REM Start Spring Boot
start "Embabel Backend" cmd /c "%MVN_CMD% spring-boot:run"
cd ..

echo Backend starting on http://localhost:8080
echo.

REM Wait for backend
echo Waiting for backend to be ready...
:wait_loop
timeout /t 1 /nobreak >nul
curl -s http://localhost:8080/api/chat/status >nul 2>&1
if errorlevel 1 (
    echo|set /p="."
    goto wait_loop
)
echo.
echo Backend is ready!
echo.

REM Start Frontend
echo Starting Frontend Server...
cd frontend

REM Install dependencies if needed
if not exist "node_modules" (
    echo Installing frontend dependencies...
    call npm install
)

REM Start Vite
start "Embabel Frontend" cmd /c "npm run dev"
cd ..

echo Frontend starting on http://localhost:3000
echo.

echo =======================================
echo   Embabel Chat is now running!
echo =======================================
echo.
echo   Frontend: http://localhost:3000
echo   Backend:  http://localhost:8080
echo   API Docs: http://localhost:8080/api/chat/status
echo.
echo   Close the command windows to stop the servers
echo.

pause
