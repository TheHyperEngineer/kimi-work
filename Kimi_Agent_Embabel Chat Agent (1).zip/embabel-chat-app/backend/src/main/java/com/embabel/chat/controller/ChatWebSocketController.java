package com.embabel.chat.controller;

import com.embabel.chat.model.*;
import com.embabel.chat.service.ChatSessionService;
import com.embabel.chat.agent.ChatOrchestratorAgent;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.messaging.simp.annotation.SubscribeMapping;
import org.springframework.stereotype.Controller;

import java.security.Principal;
import java.time.Instant;
import java.util.*;

/**
 * Chat WebSocket Controller
 * 
 * Handles WebSocket connections for real-time chat streaming.
 * Uses STOMP protocol over WebSocket for message exchange.
 * 
 * Endpoints:
 * - /app/chat.sendMessage - Send a chat message
 * - /app/chat.typing - Typing indicator
 * - /topic/chat/{conversationId} - Subscribe to conversation updates
 * - /topic/thinking/{conversationId} - Subscribe to thinking process updates
 */
@Slf4j
@Controller
@RequiredArgsConstructor
public class ChatWebSocketController {

    private final SimpMessagingTemplate messagingTemplate;
    private final ChatSessionService sessionService;
    private final ChatOrchestratorAgent orchestratorAgent;
    private final ObjectMapper objectMapper;
    
    /**
     * Handle incoming chat message
     */
    @MessageMapping("/chat.sendMessage")
    public void sendMessage(@Payload ChatMessageRequest request, Principal principal) {
        String userId = principal != null ? principal.getName() : "anonymous";
        log.info("Received message from {}: {}", userId, request.getMessage());
        
        try {
            // Get or create session
            ChatSession session = sessionService.getOrCreateSession(
                    request.getConversationId(), 
                    userId
            );
            
            // Create orchestrated request
            ChatOrchestratorAgent.OrchestratedChatRequest orchestratedRequest = 
                    new ChatOrchestratorAgent.OrchestratedChatRequest(
                            request.getMessage(),
                            session.getId(),
                            userId,
                            request.isShowThinking(),
                            request.isStreamResponse(),
                            request.getDocumentIds()
                    );
            
            // Process message through orchestrator
            // Note: In a real implementation, you'd use the Embabel AgentPlatform to run the agent
            // For this demo, we'll simulate the response
            
            // Send thinking updates if enabled
            if (request.isShowThinking()) {
                sendThinkingUpdates(session.getId());
            }
            
            // Send response chunks (simulated streaming)
            sendResponseChunks(session.getId(), request.getMessage());
            
        } catch (Exception e) {
            log.error("Error processing message", e);
            sendErrorMessage(request.getConversationId(), e.getMessage());
        }
    }
    
    /**
     * Handle typing indicator
     */
    @MessageMapping("/chat.typing")
    public void typing(@Payload TypingRequest request, Principal principal) {
        String userId = principal != null ? principal.getName() : "anonymous";
        
        TypingNotification notification = new TypingNotification(
                userId,
                request.getConversationId(),
                request.isTyping(),
                Instant.now()
        );
        
        messagingTemplate.convertAndSend(
                "/topic/typing/" + request.getConversationId(),
                notification
        );
    }
    
    /**
     * Handle subscription to conversation
     */
    @SubscribeMapping("/chat/session/{conversationId}")
    public ChatSession subscribeToSession(String conversationId) {
        ChatSession session = sessionService.getSession(conversationId);
        if (session == null) {
            // Create new session
            session = sessionService.createSession("anonymous", "New Conversation");
        }
        return session;
    }
    
    /**
     * Send thinking updates to client
     */
    private void sendThinkingUpdates(String conversationId) {
        List<ThinkingStep> steps = createThinkingSteps();
        
        for (ThinkingStep step : steps) {
            ChatResponse response = ChatResponse.thinkingUpdate(conversationId, step);
            messagingTemplate.convertAndSend(
                    "/topic/thinking/" + conversationId,
                    response
            );
            
            // Simulate processing time
            try {
                Thread.sleep(300);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
        
        // Send thinking complete
        ChatResponse completeResponse = ChatResponse.thinkingComplete(conversationId, steps);
        messagingTemplate.convertAndSend(
                "/topic/thinking/" + conversationId,
                completeResponse
        );
    }
    
    /**
     * Send response chunks (simulated streaming)
     */
    private void sendResponseChunks(String conversationId, String message) {
        // Generate a response based on the message
        String response = generateResponse(message);
        
        // Split into chunks and send
        int chunkSize = 20;
        int chunkNumber = 0;
        
        for (int i = 0; i < response.length(); i += chunkSize) {
            String chunk = response.substring(i, Math.min(i + chunkSize, response.length()));
            
            ChatResponse responseChunk = ChatResponse.contentChunk(
                    conversationId,
                    chunk,
                    chunkNumber++
            );
            
            messagingTemplate.convertAndSend(
                    "/topic/chat/" + conversationId,
                    responseChunk
            );
            
            // Simulate streaming delay
            try {
                Thread.sleep(50);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
        
        // Send complete
        ChatResponse completeResponse = ChatResponse.contentComplete(conversationId, response);
        messagingTemplate.convertAndSend(
                "/topic/chat/" + conversationId,
                completeResponse
        );
    }
    
    /**
     * Send error message
     */
    private void sendErrorMessage(String conversationId, String errorMessage) {
        ChatResponse errorResponse = ChatResponse.error(
                conversationId,
                "PROCESSING_ERROR",
                errorMessage
        );
        
        messagingTemplate.convertAndSend(
                "/topic/chat/" + conversationId,
                errorResponse
        );
    }
    
    /**
     * Create sample thinking steps
     */
    private List<ThinkingStep> createThinkingSteps() {
        List<ThinkingStep> steps = new ArrayList<>();
        
        // Step 1: Analysis
        ThinkingStep analysisStep = ThinkingStep.create(
                ThinkingStep.StepType.ANALYSIS,
                "Analyzing your question",
                "Understanding what you're asking for",
                1
        );
        analysisStep.addReasoning("Identifying key concepts and intent");
        analysisStep.addReasoning("Determining query type and complexity");
        analysisStep.complete();
        steps.add(analysisStep);
        
        // Step 2: Planning
        ThinkingStep planningStep = ThinkingStep.create(
                ThinkingStep.StepType.PLANNING,
                "Planning the approach",
                "Deciding how to best answer your question",
                2
        );
        planningStep.addReasoning("Evaluating available information sources");
        planningStep.addReasoning("Selecting appropriate tools and agents");
        planningStep.complete();
        steps.add(planningStep);
        
        // Step 3: Research
        ThinkingStep researchStep = ThinkingStep.create(
                ThinkingStep.StepType.RESEARCH,
                "Gathering information",
                "Searching for relevant data and context",
                3
        );
        researchStep.addReasoning("Checking document index for relevant content");
        researchStep.addReasoning("Retrieving contextual information");
        researchStep.complete();
        steps.add(researchStep);
        
        // Step 4: Tool Selection
        ThinkingStep toolStep = ThinkingStep.create(
                ThinkingStep.StepType.TOOL_SELECTION,
                "Selecting tools",
                "Choosing the right tools for this task",
                4
        );
        toolStep.addReasoning("ResponseAgent selected for answer generation");
        toolStep.complete();
        steps.add(toolStep);
        
        return steps;
    }
    
    /**
     * Generate a response based on the message
     */
    private String generateResponse(String message) {
        String lowerMessage = message.toLowerCase();
        
        if (lowerMessage.contains("hello") || lowerMessage.contains("hi")) {
            return "Hello! I'm your AI assistant powered by Embabel. I can help you with questions, analyze data, create visualizations, and answer questions about your documents. How can I assist you today?";
        }
        
        if (lowerMessage.contains("embabel")) {
            return "Embabel is a sophisticated agent framework for the JVM that enables building AI-powered applications with advanced planning capabilities. It uses Goal-Oriented Action Planning (GOAP) to orchestrate multiple agents and tools to accomplish complex tasks.";
        }
        
        if (lowerMessage.contains("chart") || lowerMessage.contains("graph") || lowerMessage.contains("visualization")) {
            return "I can create various types of charts and graphs including pie charts, bar charts, line charts, and more. Just let me know what data you'd like to visualize!";
        }
        
        if (lowerMessage.contains("document")) {
            return "I can help you query your ingested documents. I've processed the Embabel documentation files you provided. Feel free to ask me anything about Embabel's features, API, or how it compares to other frameworks!";
        }
        
        return "Thank you for your message! I've analyzed your query and am processing it through my multi-agent system. Is there anything specific about Embabel, data analysis, or visualizations you'd like to explore?";
    }
    
    // Request/Response DTOs
    
    public static class ChatMessageRequest {
        private String message;
        private String conversationId;
        private boolean showThinking = true;
        private boolean streamResponse = true;
        private List<String> documentIds;
        
        // Getters and setters
        public String getMessage() { return message; }
        public void setMessage(String message) { this.message = message; }
        public String getConversationId() { return conversationId; }
        public void setConversationId(String conversationId) { this.conversationId = conversationId; }
        public boolean isShowThinking() { return showThinking; }
        public void setShowThinking(boolean showThinking) { this.showThinking = showThinking; }
        public boolean isStreamResponse() { return streamResponse; }
        public void setStreamResponse(boolean streamResponse) { this.streamResponse = streamResponse; }
        public List<String> getDocumentIds() { return documentIds; }
        public void setDocumentIds(List<String> documentIds) { this.documentIds = documentIds; }
    }
    
    public static class TypingRequest {
        private String conversationId;
        private boolean typing;
        
        public String getConversationId() { return conversationId; }
        public void setConversationId(String conversationId) { this.conversationId = conversationId; }
        public boolean isTyping() { return typing; }
        public void setTyping(boolean typing) { this.typing = typing; }
    }
    
    public record TypingNotification(
            String userId,
            String conversationId,
            boolean typing,
            Instant timestamp
    ) {}
}
