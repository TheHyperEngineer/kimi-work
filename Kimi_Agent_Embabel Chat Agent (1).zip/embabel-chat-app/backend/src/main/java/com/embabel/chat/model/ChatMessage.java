package com.embabel.chat.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;
import java.util.Map;
import java.util.UUID;

/**
 * Chat Message Model
 * Represents a single message in a chat conversation.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ChatMessage {
    
    private String id;
    private String conversationId;
    private MessageRole role;
    private String content;
    private MessageType type;
    
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", timezone = "UTC")
    private Instant timestamp;
    
    // For thinking/planning messages
    private String agentName;
    private ThinkingStep thinkingStep;
    
    // For visualization messages
    private VisualizationData visualization;
    
    // Additional metadata
    private Map<String, Object> metadata;
    
    // Streaming status
    private boolean streaming;
    private boolean complete;
    
    public enum MessageRole {
        USER,           // Message from user
        ASSISTANT,      // Message from AI assistant
        SYSTEM,         // System message
        THINKING,       // Thinking/planning message
        TOOL            // Tool execution result
    }
    
    public enum MessageType {
        TEXT,           // Plain text message
        MARKDOWN,       // Markdown formatted message
        VISUALIZATION,  // Chart/graph visualization
        CODE,           // Code block
        ERROR,          // Error message
        THINKING,       // Thinking process display
        TOOL_RESULT     // Tool execution result
    }
    
    /**
     * Create a new user message
     */
    public static ChatMessage userMessage(String conversationId, String content) {
        return ChatMessage.builder()
                .id(UUID.randomUUID().toString())
                .conversationId(conversationId)
                .role(MessageRole.USER)
                .type(MessageType.TEXT)
                .content(content)
                .timestamp(Instant.now())
                .complete(true)
                .build();
    }
    
    /**
     * Create a new assistant message
     */
    public static ChatMessage assistantMessage(String conversationId, String content) {
        return ChatMessage.builder()
                .id(UUID.randomUUID().toString())
                .conversationId(conversationId)
                .role(MessageRole.ASSISTANT)
                .type(MessageType.MARKDOWN)
                .content(content)
                .timestamp(Instant.now())
                .complete(true)
                .build();
    }
    
    /**
     * Create a thinking message
     */
    public static ChatMessage thinkingMessage(String conversationId, String agentName, String content, ThinkingStep step) {
        return ChatMessage.builder()
                .id(UUID.randomUUID().toString())
                .conversationId(conversationId)
                .role(MessageRole.THINKING)
                .type(MessageType.THINKING)
                .agentName(agentName)
                .content(content)
                .thinkingStep(step)
                .timestamp(Instant.now())
                .streaming(true)
                .complete(false)
                .build();
    }
    
    /**
     * Create a visualization message
     */
    public static ChatMessage visualizationMessage(String conversationId, VisualizationData visualization) {
        return ChatMessage.builder()
                .id(UUID.randomUUID().toString())
                .conversationId(conversationId)
                .role(MessageRole.ASSISTANT)
                .type(MessageType.VISUALIZATION)
                .content(visualization != null ? visualization.getDescription() : null)
                .visualization(visualization)
                .timestamp(Instant.now())
                .complete(true)
                .build();
    }
}
