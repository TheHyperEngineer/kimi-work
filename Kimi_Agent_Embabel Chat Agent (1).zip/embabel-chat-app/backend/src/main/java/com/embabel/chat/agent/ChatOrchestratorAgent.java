package com.embabel.chat.agent;

import com.embabel.chat.model.*;
import com.embabel.chat.service.ChatSessionService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.*;

/**
 * Chat Orchestrator Agent
 * 
 * The main orchestrator that coordinates all agents to handle chat requests.
 * Implements the full OODA loop:
 * - Observe: Analyze the user query and context
 * - Orient: Plan the approach using ThinkingPlanningAgent
 * - Decide: Select appropriate agents and tools
 * - Act: Execute the plan and generate response
 * 
 * Features:
 * - Multi-agent coordination
 * - Streaming response support
 * - Thinking process visualization
 * - Document Q&A with RAG
 * - Data visualization
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class ChatOrchestratorAgent {

    private final ChatSessionService sessionService;
    private final ThinkingPlanningAgent thinkingAgent;
    private final DocumentIngestionAgent documentAgent;
    private final DataAnalysisAgent dataAnalysisAgent;
    private final VisualizationAgent visualizationAgent;
    private final ResponseAgent responseAgent;
    private final ChatClient chatClient;
    
    /**
     * Chat request for orchestration
     */
    public record OrchestratedChatRequest(
            String message,
            String conversationId,
            String userId,
            boolean showThinking,
            boolean streamResponse,
            List<String> documentIds
    ) {}
    
    /**
     * Chat response result
     */
    public record ChatResult(
            String conversationId,
            String response,
            List<ThinkingStep> thinkingSteps,
            VisualizationData visualization,
            List<String> citations,
            boolean success,
            String errorMessage
    ) {}
    
    /**
     * Process chat message (main entry point)
     */
    public ChatResult processChatMessage(OrchestratedChatRequest request) {
        log.info("Processing chat message for conversation: {}", request.conversationId());
        
        // Get or create session
        ChatSession session = sessionService.getOrCreateSession(
                request.conversationId(), 
                request.userId()
        );
        
        // Add user message to session
        ChatMessage userMessage = ChatMessage.userMessage(session.getId(), request.message());
        sessionService.addMessage(session.getId(), userMessage);
        
        try {
            // Update agent status
            sessionService.updateAgentStatus(session.getId(), ChatSession.AgentStatus.THINKING);
            
            // === STEP 1: ANALYZE QUERY ===
            log.debug("Step 1: Analyzing query");
            ThinkingPlanningAgent.QueryAnalysis analysis = thinkingAgent.analyzeQuery(
                    request.message()
            );
            
            // === STEP 2: CREATE EXECUTION PLAN ===
            log.debug("Step 2: Creating execution plan");
            ThinkingPlanningAgent.ExecutionPlan plan = thinkingAgent.createPlan(analysis);
            
            // === STEP 3: GENERATE THINKING STEPS (if enabled) ===
            List<ThinkingStep> thinkingSteps = new ArrayList<>();
            if (request.showThinking()) {
                log.debug("Step 3: Generating thinking steps");
                ThinkingPlanningAgent.ThinkingProcess thinkingProcess = 
                        thinkingAgent.generateThinkingSteps(analysis, plan);
                thinkingSteps = thinkingProcess.steps();
            }
            
            // === STEP 4: SEARCH DOCUMENTS (if needed) ===
            sessionService.updateAgentStatus(session.getId(), ChatSession.AgentStatus.EXECUTING);
            
            List<ThinkingPlanningAgent.DocumentResult> documentResults = new ArrayList<>();
            if (analysis.requiresDocumentSearch() || 
                (request.documentIds() != null && !request.documentIds().isEmpty())) {
                log.debug("Step 4: Searching documents");
                ThinkingPlanningAgent.DocumentSearchResults searchResults = 
                        thinkingAgent.searchDocumentsIfNeeded(analysis);
                documentResults = searchResults.results();
            }
            
            // === STEP 5: DATA ANALYSIS (if needed) ===
            DataAnalysisAgent.AnalysisResult dataAnalysis = null;
            if (analysis.queryType() == ThinkingPlanningAgent.QueryType.DATA_ANALYSIS ||
                analysis.queryType() == ThinkingPlanningAgent.QueryType.VISUALIZATION) {
                log.debug("Step 5: Analyzing data");
                
                // Extract or generate data
                List<DataAnalysisAgent.DataPoint> dataPoints = dataAnalysisAgent.extractDataFromQuery(
                        request.message()
                );
                
                // Analyze the data
                DataAnalysisAgent.AnalysisRequest analysisRequest = new DataAnalysisAgent.AnalysisRequest(
                        request.message(),
                        dataPoints,
                        "query"
                );
                dataAnalysis = dataAnalysisAgent.analyzeData(analysisRequest);
            }
            
            // === STEP 6: CREATE VISUALIZATION (if needed) ===
            VisualizationData visualization = null;
            if (analysis.requiresVisualization() || 
                (dataAnalysis != null && dataAnalysis.suggestedChartType() != null)) {
                log.debug("Step 6: Creating visualization");
                
                VisualizationAgent.VisualizationRequest vizRequest = new VisualizationAgent.VisualizationRequest(
                        "Data Visualization",
                        "Visualization for: " + request.message(),
                        dataAnalysis != null ? dataAnalysis.processedData() : 
                                dataAnalysisAgent.generateSampleData("default"),
                        dataAnalysis != null ? dataAnalysis.suggestedChartType() : 
                                VisualizationData.ChartType.PIE,
                        null
                );
                visualization = visualizationAgent.createVisualization(vizRequest);
            }
            
            // === STEP 7: GENERATE RESPONSE ===
            sessionService.updateAgentStatus(session.getId(), ChatSession.AgentStatus.RESPONDING);
            log.debug("Step 7: Generating response");
            
            ResponseAgent.ResponseRequest responseRequest = new ResponseAgent.ResponseRequest(
                    request.message(),
                    session.getId(),
                    analysis,
                    documentResults,
                    dataAnalysis,
                    visualization
            );
            
            ResponseAgent.GeneratedResponse generatedResponse = 
                    responseAgent.generateResponse(responseRequest);
            
            // === STEP 8: SAVE RESPONSE TO SESSION ===
            ChatMessage assistantMessage = ChatMessage.assistantMessage(
                    session.getId(),
                    generatedResponse.formattedContent()
            );
            sessionService.addMessage(session.getId(), assistantMessage);
            
            // Add visualization message if present
            if (visualization != null) {
                ChatMessage vizMessage = ChatMessage.visualizationMessage(session.getId(), visualization);
                sessionService.addMessage(session.getId(), vizMessage);
            }
            
            // Update agent status
            sessionService.updateAgentStatus(session.getId(), ChatSession.AgentStatus.IDLE);
            
            log.info("Chat message processed successfully for conversation: {}", session.getId());
            
            return new ChatResult(
                    session.getId(),
                    generatedResponse.formattedContent(),
                    thinkingSteps,
                    visualization,
                    generatedResponse.citations(),
                    true,
                    null
            );
            
        } catch (Exception e) {
            log.error("Error processing chat message", e);
            
            sessionService.updateAgentStatus(session.getId(), ChatSession.AgentStatus.IDLE);
            
            // Add error message
            ChatMessage errorMessage = ChatMessage.builder()
                    .id(UUID.randomUUID().toString())
                    .conversationId(session.getId())
                    .role(ChatMessage.MessageRole.ASSISTANT)
                    .type(ChatMessage.MessageType.ERROR)
                    .content("I apologize, but I encountered an error processing your request. Please try again.")
                    .timestamp(Instant.now())
                    .complete(true)
                    .build();
            sessionService.addMessage(session.getId(), errorMessage);
            
            return new ChatResult(
                    session.getId(),
                    "Error: " + e.getMessage(),
                    Collections.emptyList(),
                    null,
                    Collections.emptyList(),
                    false,
                    e.getMessage()
            );
        }
    }
    
    /**
     * Process a query specifically about ingested documents
     */
    public ChatResult processDocumentQuery(String message, String conversationId, 
                                           List<String> documentIds) {
        
        OrchestratedChatRequest request = new OrchestratedChatRequest(
                message,
                conversationId,
                null,
                true,
                true,
                documentIds
        );
        
        return processChatMessage(request);
    }
    
    /**
     * Process a request for data visualization
     */
    public ChatResult processVisualizationRequest(String message, String conversationId,
                                                   VisualizationData.ChartType chartType) {
        
        // Get or create session
        ChatSession session = sessionService.getOrCreateSession(conversationId, null);
        
        // Add user message
        ChatMessage userMessage = ChatMessage.userMessage(session.getId(), message);
        sessionService.addMessage(session.getId(), userMessage);
        
        try {
            // Extract or generate data
            List<DataAnalysisAgent.DataPoint> dataPoints = dataAnalysisAgent.extractDataFromQuery(
                    message
            );
            
            // Create visualization
            VisualizationAgent.VisualizationRequest vizRequest = new VisualizationAgent.VisualizationRequest(
                    "Data Visualization",
                    message,
                    dataPoints,
                    chartType,
                    null
            );
            
            VisualizationData visualization = visualizationAgent.createVisualization(vizRequest);
            
            // Generate description using ChatClient
            String description = chatClient.prompt()
                    .system("You are a helpful assistant that describes data visualizations.")
                    .user("""
                            Describe this visualization briefly:
                            Title: %s
                            Data: %s
                            """.formatted(visualization.getTitle(), dataPoints))
                    .call()
                    .content();
            
            // Add messages
            ChatMessage textMessage = ChatMessage.assistantMessage(session.getId(), description);
            sessionService.addMessage(session.getId(), textMessage);
            
            ChatMessage vizMessage = ChatMessage.visualizationMessage(session.getId(), visualization);
            sessionService.addMessage(session.getId(), vizMessage);
            
            return new ChatResult(
                    session.getId(),
                    description,
                    Collections.emptyList(),
                    visualization,
                    Collections.emptyList(),
                    true,
                    null
            );
            
        } catch (Exception e) {
            log.error("Error creating visualization", e);
            return new ChatResult(
                    session.getId(),
                    "Error creating visualization: " + e.getMessage(),
                    Collections.emptyList(),
                    null,
                    Collections.emptyList(),
                    false,
                    e.getMessage()
            );
        }
    }
    
    /**
     * Get conversation history for a session
     */
    public List<ChatMessage> getConversationHistory(String conversationId) {
        return sessionService.getRecentMessages(conversationId, 50);
    }
    
    /**
     * Clear conversation history for a session
     */
    public boolean clearConversation(String conversationId) {
        ChatSession session = sessionService.getSession(conversationId);
        if (session != null) {
            session.getMessages().clear();
            return true;
        }
        return false;
    }
}
