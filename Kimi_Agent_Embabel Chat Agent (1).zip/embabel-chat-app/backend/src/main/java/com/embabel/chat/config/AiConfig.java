package com.embabel.chat.config;

import org.springframework.ai.chat.client.ChatClient;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * AI Configuration
 * 
 * Configures Spring AI ChatClient for LLM interactions.
 */
@Configuration
public class AiConfig {

    /**
     * Create the default ChatClient builder
     */
    @Bean
    public ChatClient chatClient(ChatClient.Builder builder) {
        return builder.build();
    }
}
