package com.embabel.chat.vault;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.Map;

/**
 * Vault Agent
 * 
 * Responsible for securely managing and providing API keys
 * and other secrets to other agents in the system.
 * 
 * This agent demonstrates:
 * - Integration with external secret management systems
 * - Secure credential handling
 * - Runtime configuration retrieval
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class VaultAgent {

    private final VaultService vaultService;
    
    /**
     * API Key Request/Response records
     */
    public record ApiKeyRequest(String provider, String purpose) {}
    public record ApiKeyResponse(String provider, String key, boolean success, String message) {}
    public record ApiKeysBundle(
            String openAiKey,
            String anthropicKey,
            String googleKey,
            Map<String, String> metadata
    ) {}
    
    /**
     * Retrieve a specific API key
     */
    public ApiKeyResponse getApiKey(ApiKeyRequest request) {
        log.info("Retrieving API key for provider: {}", request.provider());
        
        String key = switch (request.provider().toLowerCase()) {
            case "openai" -> vaultService.getOpenAiApiKey();
            case "anthropic" -> vaultService.getAnthropicApiKey();
            case "google", "gemini" -> vaultService.getGoogleApiKey();
            default -> vaultService.getSecret("llm/" + request.provider() + "/api-key");
        };
        
        if (key == null) {
            return new ApiKeyResponse(
                    request.provider(),
                    null,
                    false,
                    "API key not found for provider: " + request.provider()
            );
        }
        
        // Log the access (not the key itself)
        log.info("API key accessed for provider: {}, purpose: {}", request.provider(), request.purpose());
        
        return new ApiKeyResponse(
                request.provider(),
                key,
                true,
                "API key retrieved successfully"
        );
    }
    
    /**
     * Retrieve all API keys as a bundle
     */
    public ApiKeysBundle getAllApiKeys() {
        log.info("Retrieving all API keys from vault");
        
        String openAiKey = vaultService.getOpenAiApiKey();
        String anthropicKey = vaultService.getAnthropicApiKey();
        String googleKey = vaultService.getGoogleApiKey();
        
        // Log access
        log.info("All API keys bundle accessed at {}", Instant.now());
        
        return new ApiKeysBundle(
                openAiKey,
                anthropicKey,
                googleKey,
                Map.of(
                        "source", "vault",
                        "mode", vaultService.getVaultStatus().get("mockMode") != null ? 
                                vaultService.getVaultStatus().get("mockMode").toString() : "unknown"
                )
        );
    }
    
    /**
     * Validate API key
     */
    public boolean validateApiKey(String provider) {
        String key = switch (provider.toLowerCase()) {
            case "openai" -> vaultService.getOpenAiApiKey();
            case "anthropic" -> vaultService.getAnthropicApiKey();
            case "google", "gemini" -> vaultService.getGoogleApiKey();
            default -> vaultService.getSecret("llm/" + provider + "/api-key");
        };
        
        boolean isValid = key != null && !key.isEmpty() && !key.contains("demo");
        
        log.info("API key validation for {}: {}", provider, isValid ? "valid" : "invalid/demo");
        
        return isValid;
    }
    
    /**
     * Get vault status
     */
    public Map<String, Object> getVaultStatus() {
        return vaultService.getVaultStatus();
    }
}
