package com.embabel.chat.service;

import com.embabel.chat.model.ChatMessage;
import com.embabel.chat.model.ChatSession;
import com.embabel.chat.model.ChatSession.AgentStatus;
import com.embabel.chat.model.ChatSession.SessionStatus;
import com.github.benmanes.caffeine.cache.Cache;
import com.github.benmanes.caffeine.cache.Caffeine;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import jakarta.annotation.PostConstruct;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

/**
 * Chat Session Service
 * 
 * Manages chat sessions with in-memory persistence using Caffeine cache.
 * Features:
 * - Session creation, retrieval, and deletion
 * - Automatic session expiration
 * - Message history management
 * - Context preservation across messages
 */
@Slf4j
@Service
public class ChatSessionService {

    @Value("${chat.app.session.timeout-minutes:60}")
    private int sessionTimeoutMinutes;
    
    @Value("${chat.app.session.max-concurrent:100}")
    private int maxConcurrentSessions;
    
    // Session cache with automatic expiration
    private Cache<String, ChatSession> sessionCache;
    
    // User to sessions mapping
    private final Map<String, List<String>> userSessions = new ConcurrentHashMap<>();
    
    @PostConstruct
    public void initialize() {
        log.info("Initializing Chat Session Service...");
        
        sessionCache = Caffeine.newBuilder()
                .maximumSize(maxConcurrentSessions)
                .expireAfterAccess(sessionTimeoutMinutes, TimeUnit.MINUTES)
                .removalListener((key, value, cause) -> {
                    if (value instanceof ChatSession session) {
                        log.info("Session expired/removed: {} (cause: {})", session.getId(), cause);
                    }
                })
                .recordStats()
                .build();
        
        log.info("Chat Session Service initialized with timeout: {} minutes", sessionTimeoutMinutes);
    }
    
    /**
     * Create a new chat session
     */
    public ChatSession createSession(String userId, String title) {
        String sessionId = UUID.randomUUID().toString();
        ChatSession session = ChatSession.create(userId, title);
        session.setId(sessionId);
        
        sessionCache.put(sessionId, session);
        
        // Track user's sessions
        userSessions.computeIfAbsent(userId != null ? userId : "anonymous", 
                k -> new ArrayList<>()).add(sessionId);
        
        log.info("Created new session: {} for user: {}", sessionId, userId);
        return session;
    }
    
    /**
     * Get session by ID
     */
    public ChatSession getSession(String sessionId) {
        ChatSession session = sessionCache.getIfPresent(sessionId);
        if (session != null) {
            session.touch();
        }
        return session;
    }
    
    /**
     * Get or create session
     */
    public ChatSession getOrCreateSession(String sessionId, String userId) {
        ChatSession session = getSession(sessionId);
        if (session == null) {
            session = createSession(userId, null);
        }
        return session;
    }
    
    /**
     * Add message to session
     */
    public void addMessage(String sessionId, ChatMessage message) {
        ChatSession session = getSession(sessionId);
        if (session == null) {
            throw new IllegalArgumentException("Session not found: " + sessionId);
        }
        session.addMessage(message);
        sessionCache.put(sessionId, session); // Refresh cache
    }
    
    /**
     * Update session agent status
     */
    public void updateAgentStatus(String sessionId, AgentStatus status) {
        ChatSession session = getSession(sessionId);
        if (session != null) {
            session.setAgentStatus(status);
            sessionCache.put(sessionId, session);
        }
    }
    
    /**
     * End a session
     */
    public void endSession(String sessionId) {
        ChatSession session = getSession(sessionId);
        if (session != null) {
            session.end();
            sessionCache.put(sessionId, session);
            log.info("Session ended: {}", sessionId);
        }
    }
    
    /**
     * Delete a session
     */
    public boolean deleteSession(String sessionId) {
        ChatSession session = sessionCache.getIfPresent(sessionId);
        if (session != null) {
            // Remove from user sessions
            if (session.getUserId() != null) {
                List<String> sessions = userSessions.get(session.getUserId());
                if (sessions != null) {
                    sessions.remove(sessionId);
                }
            }
            sessionCache.invalidate(sessionId);
            log.info("Session deleted: {}", sessionId);
            return true;
        }
        return false;
    }
    
    /**
     * Get all sessions for a user
     */
    public List<ChatSession> getUserSessions(String userId) {
        List<String> sessionIds = userSessions.getOrDefault(userId != null ? userId : "anonymous", 
                new ArrayList<>());
        
        return sessionIds.stream()
                .map(this::getSession)
                .filter(s -> s != null && s.getStatus() != SessionStatus.ENDED)
                .collect(Collectors.toList());
    }
    
    /**
     * Get all active sessions
     */
    public List<ChatSession> getAllActiveSessions() {
        return new ArrayList<>(sessionCache.asMap().values()).stream()
                .filter(s -> s.getStatus() == SessionStatus.ACTIVE)
                .collect(Collectors.toList());
    }
    
    /**
     * Get recent messages from session
     */
    public List<ChatMessage> getRecentMessages(String sessionId, int count) {
        ChatSession session = getSession(sessionId);
        if (session == null) {
            return new ArrayList<>();
        }
        return session.getRecentMessages(count);
    }
    
    /**
     * Get conversation history for LLM context
     */
    public String getConversationHistory(String sessionId, int maxMessages) {
        ChatSession session = getSession(sessionId);
        if (session == null) {
            return "";
        }
        return session.getFormattedHistory(maxMessages);
    }
    
    /**
     * Update session context
     */
    public void updateSessionContext(String sessionId, String key, Object value) {
        ChatSession session = getSession(sessionId);
        if (session != null) {
            session.setContextValue(key, value);
            sessionCache.put(sessionId, session);
        }
    }
    
    /**
     * Get session context value
     */
    public Object getSessionContext(String sessionId, String key) {
        ChatSession session = getSession(sessionId);
        if (session != null) {
            return session.getContextValue(key);
        }
        return null;
    }
    
    /**
     * Add document to session
     */
    public void addDocumentToSession(String sessionId, String documentId) {
        ChatSession session = getSession(sessionId);
        if (session != null) {
            session.addDocument(documentId);
            sessionCache.put(sessionId, session);
        }
    }
    
    /**
     * Get session statistics
     */
    public Map<String, Object> getStatistics() {
        return Map.of(
                "totalSessions", sessionCache.estimatedSize(),
                "activeSessions", getAllActiveSessions().size(),
                "hitRate", sessionCache.stats().hitRate(),
                "missRate", sessionCache.stats().missRate(),
                "evictionCount", sessionCache.stats().evictionCount()
        );
    }
    
    /**
     * Clean up expired sessions
     */
    public void cleanupExpiredSessions() {
        log.info("Cleaning up expired sessions...");
        sessionCache.cleanUp();
    }
    
    /**
     * Check if session exists
     */
    public boolean sessionExists(String sessionId) {
        return sessionCache.getIfPresent(sessionId) != null;
    }
    
    /**
     * Update session title
     */
    public void updateSessionTitle(String sessionId, String title) {
        ChatSession session = getSession(sessionId);
        if (session != null) {
            session.setTitle(title);
            sessionCache.put(sessionId, session);
        }
    }
}
