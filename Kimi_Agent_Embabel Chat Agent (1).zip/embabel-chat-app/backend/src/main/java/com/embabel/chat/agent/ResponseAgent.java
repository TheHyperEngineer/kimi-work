package com.embabel.chat.agent;

import com.embabel.chat.model.VisualizationData;
import com.embabel.chat.service.ChatSessionService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.stereotype.Component;

import java.util.*;

/**
 * Response Agent
 * 
 * Generates the final response to the user based on:
 * - Original query
 * - Query analysis
 * - Document search results (if applicable)
 * - Data analysis results (if applicable)
 * - Visualization data (if applicable)
 * 
 * Features:
 * - Streaming response generation
 * - Context-aware responses
 * - Citation of sources
 * - Markdown formatting
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class ResponseAgent {

    private final ChatSessionService sessionService;
    private final ChatClient chatClient;
    
    /**
     * Response generation request
     */
    public record ResponseRequest(
            String query,
            String conversationId,
            ThinkingPlanningAgent.QueryAnalysis analysis,
            List<ThinkingPlanningAgent.DocumentResult> documentResults,
            DataAnalysisAgent.AnalysisResult dataAnalysis,
            VisualizationData visualization
    ) {}
    
    /**
     * Generated response
     */
    public record GeneratedResponse(
            String content,
            String formattedContent,
            List<String> citations,
            Map<String, Object> metadata,
            boolean hasVisualization
    ) {}
    
    /**
     * Generate response
     */
    public GeneratedResponse generateResponse(ResponseRequest request) {
        log.info("Generating response for query: {}", request.query());
        
        // Get conversation history for context
        String conversationHistory = "";
        if (request.conversationId() != null) {
            conversationHistory = sessionService.getConversationHistory(request.conversationId(), 10);
        }
        
        // Build context from document results
        String documentContext = buildDocumentContext(request.documentResults());
        
        // Build data analysis context
        String dataContext = buildDataContext(request.dataAnalysis());
        
        // Determine response style based on query type
        String responseStyle = determineResponseStyle(request.analysis());
        
        // Generate response using LLM
        String response = chatClient.prompt()
                .system("You are a helpful AI assistant. " + responseStyle)
                .user(buildPrompt(request, conversationHistory, documentContext, dataContext, responseStyle))
                .call()
                .content();
        
        // Format the response
        String formattedResponse = formatResponse(response, request);
        
        // Extract citations
        List<String> citations = extractCitations(request.documentResults());
        
        log.info("Response generated successfully (length: {} chars)", response.length());
        
        return new GeneratedResponse(
                response,
                formattedResponse,
                citations,
                Map.of(
                        "queryType", request.analysis().queryType(),
                        "hasDocuments", request.documentResults() != null && !request.documentResults().isEmpty(),
                        "hasAnalysis", request.dataAnalysis() != null,
                        "hasVisualization", request.visualization() != null
                ),
                request.visualization() != null
        );
    }
    
    /**
     * Generate streaming response chunk
     */
    public String generateResponseChunk(
            String query,
            String partialResponse,
            int chunkNumber) {
        
        // For streaming, we generate the full response and then chunk it
        // In a real implementation, you might use a streaming LLM API
        return chatClient.prompt()
                .system("You are a helpful AI assistant. Continue the response.")
                .user("""
                        Continue the response to: "%s"
                        Previous content: "%s"
                        Generate the next sentence or two.
                        """.formatted(query, partialResponse))
                .call()
                .content();
    }
    
    /**
     * Format response with citations
     */
    public String formatResponse(String content, ResponseRequest request) {
        StringBuilder formatted = new StringBuilder();
        
        // Add main content
        formatted.append(content);
        
        // Add citations if document results exist
        if (request.documentResults() != null && !request.documentResults().isEmpty()) {
            formatted.append("\n\n---\n\n**Sources:**\n\n");
            int citationNum = 1;
            for (ThinkingPlanningAgent.DocumentResult result : request.documentResults()) {
                String source = result.metadata() != null ? 
                        result.metadata().getOrDefault("source", "Unknown").toString() : 
                        "Document";
                formatted.append(citationNum).append(". ")
                        .append(source)
                        .append(" (relevance: ")
                        .append(String.format("%.2f", result.score()))
                        .append(")\n");
                citationNum++;
            }
        }
        
        return formatted.toString();
    }
    
    /**
     * Summarize long responses
     */
    public String summarizeResponse(String content) {
        if (content.length() < 500) {
            return content;
        }
        
        return chatClient.prompt()
                .system("You are a helpful AI assistant. Summarize content concisely.")
                .user("""
                        Summarize the following response in 2-3 sentences:
                        
                        %s
                        """.formatted(content.substring(0, Math.min(content.length(), 2000))))
                .call()
                .content();
    }
    
    /**
     * Build the prompt for response generation
     */
    private String buildPrompt(
            ResponseRequest request,
            String conversationHistory,
            String documentContext,
            String dataContext,
            String responseStyle) {
        
        StringBuilder prompt = new StringBuilder();
        
        prompt.append("Generate a response to the following user query.\n\n");
        prompt.append("Query: \"").append(request.query()).append("\"\n\n");
        
        // Add conversation history
        if (!conversationHistory.isEmpty()) {
            prompt.append("Conversation context:\n").append(conversationHistory).append("\n\n");
        }
        
        // Add document context if available
        if (!documentContext.isEmpty()) {
            prompt.append("Relevant document content:\n").append(documentContext).append("\n\n");
        }
        
        // Add data analysis context if available
        if (!dataContext.isEmpty()) {
            prompt.append("Data analysis results:\n").append(dataContext).append("\n\n");
        }
        
        // Add response style instructions
        prompt.append("Response style: ").append(responseStyle).append("\n\n");
        
        // Add formatting instructions
        prompt.append("""
                Format your response using Markdown:
                - Use headers (##) for sections
                - Use bullet points for lists
                - Use code blocks for any code
                - Use bold for emphasis
                - Include citations to sources where applicable
                
                Provide a comprehensive and helpful response.
                """);
        
        return prompt.toString();
    }
    
    /**
     * Build document context from search results
     */
    private String buildDocumentContext(List<ThinkingPlanningAgent.DocumentResult> results) {
        if (results == null || results.isEmpty()) {
            return "";
        }
        
        StringBuilder context = new StringBuilder();
        int count = 1;
        for (ThinkingPlanningAgent.DocumentResult result : results) {
            context.append("[").append(count).append("] ");
            context.append(result.content().substring(0, 
                    Math.min(result.content().length(), 500)));
            context.append("\n\n");
            count++;
        }
        
        return context.toString();
    }
    
    /**
     * Build data context from analysis results
     */
    private String buildDataContext(DataAnalysisAgent.AnalysisResult analysis) {
        if (analysis == null) {
            return "";
        }
        
        return """
                Key insights: %s
                Trends: %s
                Recommendations: %s
                """.formatted(
                analysis.insights(),
                analysis.trends(),
                analysis.recommendations()
        );
    }
    
    /**
     * Determine response style based on query type
     */
    private String determineResponseStyle(ThinkingPlanningAgent.QueryAnalysis analysis) {
        return switch (analysis.queryType()) {
            case DOCUMENT_QUERY -> 
                    "Informative and factual, citing specific information from documents";
            case DATA_ANALYSIS -> 
                    "Analytical and data-driven, highlighting key insights and trends";
            case VISUALIZATION -> 
                    "Descriptive, explaining what the visualization shows";
            case COMPARISON -> 
                    "Structured comparison, highlighting similarities and differences";
            case CODE -> 
                    "Technical, with clear code examples and explanations";
            case CREATIVE -> 
                    "Creative and engaging, with vivid language";
            case CONVERSATIONAL -> 
                    "Friendly and conversational, natural tone";
            default -> 
                    "Clear and helpful, direct answer to the question";
        };
    }
    
    /**
     * Extract citations from document results
     */
    private List<String> extractCitations(List<ThinkingPlanningAgent.DocumentResult> results) {
        if (results == null || results.isEmpty()) {
            return Collections.emptyList();
        }
        
        List<String> citations = new ArrayList<>();
        for (ThinkingPlanningAgent.DocumentResult result : results) {
            String source = result.metadata() != null ? 
                    result.metadata().getOrDefault("source", "Unknown").toString() : 
                    "Document";
            citations.add(source);
        }
        
        return citations;
    }
}
