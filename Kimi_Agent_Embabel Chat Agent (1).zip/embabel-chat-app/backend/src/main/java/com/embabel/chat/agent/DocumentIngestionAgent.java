package com.embabel.chat.agent;

import lombok.extern.slf4j.Slf4j;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.stereotype.Component;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.net.MalformedURLException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Instant;
import java.util.*;

/**
 * Document Ingestion Agent
 * 
 * Processes and ingests documents for RAG (Retrieval-Augmented Generation).
 * Supports PDF, Markdown, TXT, and DOCX files.
 * 
 * Features:
 * - Document parsing and text extraction
 * - Chunking and embedding generation
 * - Vector storage (simplified in-memory implementation)
 * - Document metadata tracking
 */
@Slf4j
@Component
public class DocumentIngestionAgent {
    
    // In-memory document registry
    private final Map<String, DocumentInfo> documentRegistry = new HashMap<>();
    
    // In-memory document content storage (simplified RAG)
    private final Map<String, List<DocumentChunk>> documentChunks = new HashMap<>();
    
    /**
     * Document info record
     */
    public record DocumentInfo(
            String documentId,
            String filename,
            String filePath,
            String contentType,
            long fileSize,
            int chunkCount,
            Instant ingestedAt,
            DocumentStatus status,
            Map<String, Object> metadata
    ) {}
    
    public enum DocumentStatus {
        PENDING,        // Waiting to be processed
        PROCESSING,     // Currently being processed
        INGESTED,       // Successfully ingested
        FAILED,         // Processing failed
        REMOVED         // Removed from index
    }
    
    /**
     * Document chunk for RAG
     */
    public record DocumentChunk(
            String chunkId,
            String documentId,
            String content,
            int chunkIndex,
            Map<String, Object> metadata
    ) {}
    
    /**
     * Document ingestion request
     */
    public record IngestionRequest(
            String filePath,
            String documentId,
            Map<String, Object> metadata
    ) {}
    
    /**
     * Document ingestion result
     */
    public record IngestionResult(
            String documentId,
            boolean success,
            String message,
            int chunksCreated,
            DocumentInfo documentInfo
    ) {}
    
    /**
     * Ingest a document from file path
     */
    public IngestionResult ingestDocument(IngestionRequest request) {
        String docId = request.documentId() != null ? request.documentId() : UUID.randomUUID().toString();
        log.info("Ingesting document: {} from path: {}", docId, request.filePath());
        
        try {
            // Create document info
            DocumentInfo docInfo = new DocumentInfo(
                    docId,
                    Paths.get(request.filePath()).getFileName().toString(),
                    request.filePath(),
                    detectContentType(request.filePath()),
                    new File(request.filePath()).length(),
                    0,
                    Instant.now(),
                    DocumentStatus.PROCESSING,
                    request.metadata()
            );
            documentRegistry.put(docId, docInfo);
            
            // Parse and extract content from the document
            String content = extractContent(request.filePath());
            
            // Chunk the content
            List<DocumentChunk> chunks = chunkContent(docId, content);
            documentChunks.put(docId, chunks);
            
            // Update document info
            DocumentInfo updatedInfo = new DocumentInfo(
                    docId,
                    docInfo.filename(),
                    docInfo.filePath(),
                    docInfo.contentType(),
                    docInfo.fileSize(),
                    chunks.size(),
                    docInfo.ingestedAt(),
                    DocumentStatus.INGESTED,
                    docInfo.metadata()
            );
            documentRegistry.put(docId, updatedInfo);
            
            log.info("Document ingested successfully: {} with {} chunks", docId, chunks.size());
            
            return new IngestionResult(
                    docId,
                    true,
                    "Document ingested successfully",
                    chunks.size(),
                    updatedInfo
            );
            
        } catch (Exception e) {
            log.error("Failed to ingest document: {}", docId, e);
            
            DocumentInfo failedInfo = new DocumentInfo(
                    docId,
                    Paths.get(request.filePath()).getFileName().toString(),
                    request.filePath(),
                    detectContentType(request.filePath()),
                    0,
                    0,
                    Instant.now(),
                    DocumentStatus.FAILED,
                    Map.of("error", e.getMessage())
            );
            documentRegistry.put(docId, failedInfo);
            
            return new IngestionResult(
                    docId,
                    false,
                    "Ingestion failed: " + e.getMessage(),
                    0,
                    failedInfo
            );
        }
    }
    
    /**
     * Ingest multiple documents
     */
    public List<IngestionResult> ingestMultipleDocuments(List<String> filePaths) {
        List<IngestionResult> results = new ArrayList<>();
        
        for (String filePath : filePaths) {
            IngestionRequest request = new IngestionRequest(filePath, null, null);
            results.add(ingestDocument(request));
        }
        
        return results;
    }
    
    /**
     * Get document info
     */
    public DocumentInfo getDocumentInfo(String documentId) {
        return documentRegistry.get(documentId);
    }
    
    /**
     * List all ingested documents
     */
    public List<DocumentInfo> listDocuments() {
        return new ArrayList<>(documentRegistry.values());
    }
    
    /**
     * Search documents
     */
    public List<DocumentSearchResult> searchDocuments(String query) {
        log.info("Searching documents for query: {}", query);
        
        List<DocumentSearchResult> results = new ArrayList<>();
        String lowerQuery = query.toLowerCase();
        
        // Simple keyword-based search
        for (Map.Entry<String, List<DocumentChunk>> entry : documentChunks.entrySet()) {
            for (DocumentChunk chunk : entry.getValue()) {
                if (chunk.content().toLowerCase().contains(lowerQuery)) {
                    // Calculate a simple relevance score
                    double score = calculateRelevanceScore(chunk.content(), lowerQuery);
                    
                    DocumentInfo docInfo = documentRegistry.get(chunk.documentId());
                    results.add(new DocumentSearchResult(
                            chunk.documentId(),
                            chunk.content(),
                            score,
                            Map.of(
                                    "chunkIndex", chunk.chunkIndex(),
                                    "source", docInfo != null ? docInfo.filename() : "Unknown"
                            )
                    ));
                }
            }
        }
        
        // Sort by relevance score
        results.sort((a, b) -> Double.compare(b.score(), a.score()));
        
        // Return top 10 results
        return results.size() > 10 ? results.subList(0, 10) : results;
    }
    
    /**
     * Remove document from index
     */
    public boolean removeDocument(String documentId) {
        log.info("Removing document from index: {}", documentId);
        
        DocumentInfo docInfo = documentRegistry.get(documentId);
        if (docInfo != null) {
            // Update status
            DocumentInfo removedInfo = new DocumentInfo(
                    docInfo.documentId(),
                    docInfo.filename(),
                    docInfo.filePath(),
                    docInfo.contentType(),
                    docInfo.fileSize(),
                    docInfo.chunkCount(),
                    docInfo.ingestedAt(),
                    DocumentStatus.REMOVED,
                    docInfo.metadata()
            );
            documentRegistry.put(documentId, removedInfo);
            
            // Remove chunks
            documentChunks.remove(documentId);
            
            return true;
        }
        return false;
    }
    
    /**
     * Get document statistics
     */
    public DocumentStatistics getStatistics() {
        long totalDocs = documentRegistry.size();
        long ingested = documentRegistry.values().stream()
                .filter(d -> d.status() == DocumentStatus.INGESTED)
                .count();
        long failed = documentRegistry.values().stream()
                .filter(d -> d.status() == DocumentStatus.FAILED)
                .count();
        long totalChunks = documentChunks.values().stream()
                .mapToLong(List::size)
                .sum();
        
        return new DocumentStatistics(
                totalDocs,
                ingested,
                failed,
                totalChunks,
                totalChunks
        );
    }
    
    /**
     * Document search result
     */
    public record DocumentSearchResult(
            String documentId,
            String content,
            double score,
            Map<String, Object> metadata
    ) {}
    
    /**
     * Document statistics
     */
    public record DocumentStatistics(
            long totalDocuments,
            long ingestedDocuments,
            long failedDocuments,
            long totalChunks,
            long indexedDocuments
    ) {}
    
    /**
     * Extract content from file
     */
    private String extractContent(String filePath) throws IOException {
        File file = new File(filePath);
        
        if (!file.exists()) {
            throw new IOException("File not found: " + filePath);
        }
        
        String contentType = detectContentType(filePath);
        
        return switch (contentType) {
            case "text/plain", "text/markdown" -> readTextFile(file);
            default -> {
                // For other types, try to read as text
                log.warn("Using generic text extraction for: {}", contentType);
                yield readTextFile(file);
            }
        };
    }
    
    /**
     * Read text file
     */
    private String readTextFile(File file) throws IOException {
        StringBuilder content = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                content.append(line).append("\n");
            }
        }
        return content.toString();
    }
    
    /**
     * Chunk content into smaller pieces
     */
    private List<DocumentChunk> chunkContent(String documentId, String content) {
        List<DocumentChunk> chunks = new ArrayList<>();
        
        // Simple chunking strategy: split by paragraphs and combine to target size
        String[] paragraphs = content.split("\n\n");
        StringBuilder currentChunk = new StringBuilder();
        int chunkIndex = 0;
        int targetChunkSize = 1000; // characters
        
        for (String paragraph : paragraphs) {
            if (currentChunk.length() + paragraph.length() > targetChunkSize && currentChunk.length() > 0) {
                // Save current chunk
                chunks.add(new DocumentChunk(
                        UUID.randomUUID().toString(),
                        documentId,
                        currentChunk.toString().trim(),
                        chunkIndex++,
                        Map.of()
                ));
                currentChunk = new StringBuilder();
            }
            currentChunk.append(paragraph).append("\n\n");
        }
        
        // Don't forget the last chunk
        if (currentChunk.length() > 0) {
            chunks.add(new DocumentChunk(
                    UUID.randomUUID().toString(),
                    documentId,
                    currentChunk.toString().trim(),
                    chunkIndex,
                    Map.of()
            ));
        }
        
        return chunks;
    }
    
    /**
     * Calculate relevance score
     */
    private double calculateRelevanceScore(String content, String query) {
        String lowerContent = content.toLowerCase();
        String[] queryWords = query.split("\\s+");
        
        int matches = 0;
        for (String word : queryWords) {
            if (lowerContent.contains(word)) {
                matches++;
            }
        }
        
        return (double) matches / queryWords.length;
    }
    
    /**
     * Detect content type from file extension
     */
    private String detectContentType(String filePath) {
        String lowerPath = filePath.toLowerCase();
        if (lowerPath.endsWith(".pdf")) return "application/pdf";
        if (lowerPath.endsWith(".md")) return "text/markdown";
        if (lowerPath.endsWith(".txt")) return "text/plain";
        if (lowerPath.endsWith(".docx")) return "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
        if (lowerPath.endsWith(".doc")) return "application/msword";
        return "application/octet-stream";
    }
    
    /**
     * Get document registry (for service access)
     */
    public Map<String, DocumentInfo> getDocumentRegistry() {
        return Collections.unmodifiableMap(documentRegistry);
    }
}
