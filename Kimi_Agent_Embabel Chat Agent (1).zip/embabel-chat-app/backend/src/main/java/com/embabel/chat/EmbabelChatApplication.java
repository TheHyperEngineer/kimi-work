package com.embabel.chat;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.scheduling.annotation.EnableAsync;

/**
 * Embabel Chat Application - Main Entry Point
 * 
 * A modern AI chat application built with:
 * - Embabel 0.3.4 Agent Framework
 * - Spring Boot 3.3.5
 * - React Frontend
 * 
 * Features:
 * - Multi-agent orchestration (Thinking, Planning, Response agents)
 * - Streaming responses via WebSocket
 * - Data visualization support (charts/graphs)
 * - In-memory session and state persistence
 * - Document Q&A with RAG
 * - Vault integration for API key management
 */
@SpringBootApplication
@EnableCaching
@EnableAsync
public class EmbabelChatApplication {

    public static void main(String[] args) {
        SpringApplication.run(EmbabelChatApplication.class, args);
    }
}
