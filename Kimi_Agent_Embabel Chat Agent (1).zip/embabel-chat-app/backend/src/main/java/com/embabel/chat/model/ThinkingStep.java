package com.embabel.chat.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Thinking Step Model
 * Represents a step in the agent's thinking/planning process.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ThinkingStep {
    
    private String stepId;
    private StepType type;
    private String title;
    private String description;
    private int order;
    
    // Timing information
    private Instant startedAt;
    private Instant completedAt;
    private long durationMs;
    
    // Step details
    private List<String> reasoning;
    private List<String> considerations;
    private String decision;
    private double confidence;
    
    // Sub-steps for complex planning
    private List<ThinkingStep> subSteps;
    
    // Tool usage information
    private List<ToolUsage> toolsUsed;
    
    // Status
    private StepStatus status;
    
    // Additional context
    private Map<String, Object> context;
    
    public enum StepType {
        ANALYSIS,       // Analyzing the user query
        PLANNING,       // Planning the approach
        RESEARCH,       // Researching information
        REASONING,      // Reasoning about the problem
        TOOL_SELECTION, // Selecting appropriate tools
        EXECUTION,      // Executing the plan
        REVIEW,         // Reviewing the result
        FINALIZING      // Finalizing the response
    }
    
    public enum StepStatus {
        PENDING,        // Step is pending
        IN_PROGRESS,    // Step is currently executing
        COMPLETED,      // Step completed successfully
        FAILED,         // Step failed
        SKIPPED         // Step was skipped
    }
    
    /**
     * Tool usage information
     */
    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class ToolUsage {
        private String toolName;
        private String description;
        private Map<String, Object> parameters;
        private Object result;
        private boolean success;
        private long executionTimeMs;
    }
    
    /**
     * Create a new thinking step
     */
    public static ThinkingStep create(StepType type, String title, String description, int order) {
        ThinkingStep step = new ThinkingStep();
        step.setStepId(UUID.randomUUID().toString());
        step.setType(type);
        step.setTitle(title);
        step.setDescription(description);
        step.setOrder(order);
        step.setStatus(StepStatus.IN_PROGRESS);
        step.setStartedAt(Instant.now());
        step.setReasoning(new ArrayList<>());
        step.setConsiderations(new ArrayList<>());
        step.setToolsUsed(new ArrayList<>());
        return step;
    }
    
    /**
     * Mark the step as completed
     */
    public void complete() {
        this.status = StepStatus.COMPLETED;
        this.completedAt = Instant.now();
        this.durationMs = java.time.Duration.between(startedAt, completedAt).toMillis();
    }
    
    /**
     * Mark the step as failed
     */
    public void fail(String reason) {
        this.status = StepStatus.FAILED;
        this.completedAt = Instant.now();
        this.durationMs = java.time.Duration.between(startedAt, completedAt).toMillis();
        if (this.reasoning == null) {
            this.reasoning = new ArrayList<>();
        }
        this.reasoning.add("Failed: " + reason);
    }
    
    /**
     * Add reasoning text
     */
    public void addReasoning(String text) {
        if (this.reasoning == null) {
            this.reasoning = new ArrayList<>();
        }
        this.reasoning.add(text);
    }
    
    /**
     * Add a consideration
     */
    public void addConsideration(String consideration) {
        if (this.considerations == null) {
            this.considerations = new ArrayList<>();
        }
        this.considerations.add(consideration);
    }
    
    /**
     * Add tool usage
     */
    public void addToolUsage(ToolUsage tool) {
        if (this.toolsUsed == null) {
            this.toolsUsed = new ArrayList<>();
        }
        this.toolsUsed.add(tool);
    }
}
