package com.embabel.chat.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;
import java.util.List;
import java.util.Map;

/**
 * Chat Response DTO
 * Represents a chat message response to the client.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ChatResponse {
    
    /**
     * Response ID
     */
    private String id;
    
    /**
     * Conversation ID
     */
    private String conversationId;
    
    /**
     * Response type
     */
    private ResponseType type;
    
    /**
     * Response content
     */
    private String content;
    
    /**
     * Response status
     */
    private ResponseStatus status;
    
    /**
     * Timestamp
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", timezone = "UTC")
    private Instant timestamp;
    
    /**
     * Thinking steps (if showThinking is enabled)
     */
    private List<ThinkingStep> thinkingSteps;
    
    /**
     * Current thinking step being processed
     */
    private ThinkingStep currentThinkingStep;
    
    /**
     * Visualization data (if applicable)
     */
    private VisualizationData visualization;
    
    /**
     * Related messages (for context)
     */
    private List<ChatMessage> relatedMessages;
    
    /**
     * Agent that generated this response
     */
    private String agentName;
    
    /**
     * Whether this is the final chunk in a stream
     */
    private boolean finalChunk;
    
    /**
     * Chunk sequence number (for streaming)
     */
    private int chunkNumber;
    
    /**
     * Error information (if status is ERROR)
     */
    private ErrorInfo error;
    
    /**
     * Additional metadata
     */
    private Map<String, Object> metadata;
    
    public enum ResponseType {
        THINKING_START,     // Thinking process started
        THINKING_UPDATE,    // Thinking step update
        THINKING_COMPLETE,  // Thinking process completed
        CONTENT_CHUNK,      // Content chunk (streaming)
        CONTENT_COMPLETE,   // Content streaming completed
        VISUALIZATION,      // Visualization data
        TOOL_RESULT,        // Tool execution result
        ERROR,              // Error response
        SYSTEM              // System message
    }
    
    public enum ResponseStatus {
        SUCCESS,            // Successful response
        PARTIAL,            // Partial response (streaming)
        ERROR,              // Error occurred
        CANCELLED,          // Request was cancelled
        TIMEOUT             // Request timed out
    }
    
    /**
     * Error information
     */
    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class ErrorInfo {
        private String code;
        private String message;
        private String details;
        private boolean retryable;
    }
    
    /**
     * Create a thinking start response
     */
    public static ChatResponse thinkingStart(String conversationId, String agentName) {
        return ChatResponse.builder()
                .id(java.util.UUID.randomUUID().toString())
                .conversationId(conversationId)
                .type(ResponseType.THINKING_START)
                .agentName(agentName)
                .status(ResponseStatus.PARTIAL)
                .timestamp(Instant.now())
                .finalChunk(false)
                .build();
    }
    
    /**
     * Create a thinking update response
     */
    public static ChatResponse thinkingUpdate(String conversationId, ThinkingStep step) {
        return ChatResponse.builder()
                .id(java.util.UUID.randomUUID().toString())
                .conversationId(conversationId)
                .type(ResponseType.THINKING_UPDATE)
                .currentThinkingStep(step)
                .status(ResponseStatus.PARTIAL)
                .timestamp(Instant.now())
                .finalChunk(false)
                .build();
    }
    
    /**
     * Create a thinking complete response
     */
    public static ChatResponse thinkingComplete(String conversationId, List<ThinkingStep> steps) {
        return ChatResponse.builder()
                .id(java.util.UUID.randomUUID().toString())
                .conversationId(conversationId)
                .type(ResponseType.THINKING_COMPLETE)
                .thinkingSteps(steps)
                .status(ResponseStatus.SUCCESS)
                .timestamp(Instant.now())
                .finalChunk(false)
                .build();
    }
    
    /**
     * Create a content chunk response
     */
    public static ChatResponse contentChunk(String conversationId, String content, int chunkNumber) {
        return ChatResponse.builder()
                .id(java.util.UUID.randomUUID().toString())
                .conversationId(conversationId)
                .type(ResponseType.CONTENT_CHUNK)
                .content(content)
                .status(ResponseStatus.PARTIAL)
                .timestamp(Instant.now())
                .chunkNumber(chunkNumber)
                .finalChunk(false)
                .build();
    }
    
    /**
     * Create a content complete response
     */
    public static ChatResponse contentComplete(String conversationId, String fullContent) {
        return ChatResponse.builder()
                .id(java.util.UUID.randomUUID().toString())
                .conversationId(conversationId)
                .type(ResponseType.CONTENT_COMPLETE)
                .content(fullContent)
                .status(ResponseStatus.SUCCESS)
                .timestamp(Instant.now())
                .finalChunk(true)
                .build();
    }
    
    /**
     * Create a visualization response
     */
    public static ChatResponse visualization(String conversationId, VisualizationData visualization) {
        return ChatResponse.builder()
                .id(java.util.UUID.randomUUID().toString())
                .conversationId(conversationId)
                .type(ResponseType.VISUALIZATION)
                .visualization(visualization)
                .status(ResponseStatus.SUCCESS)
                .timestamp(Instant.now())
                .finalChunk(false)
                .build();
    }
    
    /**
     * Create an error response
     */
    public static ChatResponse error(String conversationId, String errorCode, String errorMessage) {
        return ChatResponse.builder()
                .id(java.util.UUID.randomUUID().toString())
                .conversationId(conversationId)
                .type(ResponseType.ERROR)
                .status(ResponseStatus.ERROR)
                .error(ErrorInfo.builder()
                        .code(errorCode)
                        .message(errorMessage)
                        .retryable(false)
                        .build())
                .timestamp(Instant.now())
                .finalChunk(true)
                .build();
    }
}
