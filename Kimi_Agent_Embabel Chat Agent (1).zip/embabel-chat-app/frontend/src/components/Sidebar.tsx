import { useState } from 'react';
import { ChatSession } from '@/types';
import { cn, formatDate, truncateText } from '@/utils/helpers';
import { 
  Plus, 
  MessageSquare, 
  Trash2, 
  ChevronLeft, 
  ChevronRight,
  MoreVertical,
  FileText
} from 'lucide-react';

interface SidebarProps {
  sessions: ChatSession[];
  currentSession: ChatSession | null;
  onSelectSession: (session: ChatSession) => void;
  onCreateSession: () => void;
  onDeleteSession: (sessionId: string) => void;
  isOpen: boolean;
  onToggle: () => void;
}

export function Sidebar({
  sessions,
  currentSession,
  onSelectSession,
  onCreateSession,
  onDeleteSession,
  isOpen,
  onToggle,
}: SidebarProps) {
  const [hoveredSession, setHoveredSession] = useState<string | null>(null);

  return (
    <>
      {/* Mobile overlay */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-40 lg:hidden"
          onClick={onToggle}
        />
      )}

      {/* Sidebar */}
      <aside
        className={cn(
          'fixed lg:static inset-y-0 left-0 z-50 bg-card border-r border-border transition-all duration-300',
          isOpen ? 'w-80 translate-x-0' : 'w-0 -translate-x-full lg:w-16 lg:translate-x-0'
        )}
      >
        <div className="h-full flex flex-col">
          {/* Header */}
          <div className="p-4 border-b border-border flex items-center justify-between">
            {isOpen ? (
              <>
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center">
                    <MessageSquare className="w-4 h-4 text-primary-foreground" />
                  </div>
                  <span className="font-semibold">Embabel Chat</span>
                </div>
                <button
                  onClick={onToggle}
                  className="p-1.5 hover:bg-muted rounded-lg transition-colors lg:block hidden"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>
              </>
            ) : (
              <button
                onClick={onToggle}
                className="p-2 hover:bg-muted rounded-lg transition-colors mx-auto"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* New chat button */}
          {isOpen && (
            <div className="p-4">
              <button
                onClick={onCreateSession}
                className="w-full flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors"
              >
                <Plus className="w-4 h-4" />
                <span>New Chat</span>
              </button>
            </div>
          )}

          {/* Sessions list */}
          {isOpen && (
            <div className="flex-1 overflow-y-auto px-2">
              <div className="text-xs font-medium text-muted-foreground uppercase tracking-wider px-2 py-2">
                Recent Conversations
              </div>
              
              {sessions.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  <FileText className="w-8 h-8 mx-auto mb-2 opacity-50" />
                  <p className="text-sm">No conversations yet</p>
                  <p className="text-xs mt-1">Start a new chat to begin</p>
                </div>
              ) : (
                <div className="space-y-1">
                  {sessions.map((session) => (
                    <div
                      key={session.id}
                      className={cn(
                        'group relative flex items-center gap-3 px-3 py-2.5 rounded-lg cursor-pointer transition-colors',
                        currentSession?.id === session.id
                          ? 'bg-primary/10 text-primary'
                          : 'hover:bg-muted'
                      )}
                      onClick={() => onSelectSession(session)}
                      onMouseEnter={() => setHoveredSession(session.id)}
                      onMouseLeave={() => setHoveredSession(null)}
                    >
                      <MessageSquare className="w-4 h-4 flex-shrink-0" />
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium truncate">
                          {session.title || 'Untitled Conversation'}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          {formatDate(session.lastActivityAt)}
                        </p>
                      </div>
                      
                      {(hoveredSession === session.id || currentSession?.id === session.id) && (
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            onDeleteSession(session.id);
                          }}
                          className="p-1.5 hover:bg-destructive/10 hover:text-destructive rounded transition-colors opacity-0 group-hover:opacity-100"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Collapsed state - icons only */}
          {!isOpen && (
            <div className="flex-1 overflow-y-auto py-2">
              <button
                onClick={onCreateSession}
                className="w-full p-3 hover:bg-muted transition-colors flex justify-center"
                title="New Chat"
              >
                <Plus className="w-5 h-5" />
              </button>
              
              <div className="border-t border-border my-2" />
              
              {sessions.slice(0, 5).map((session) => (
                <button
                  key={session.id}
                  onClick={() => onSelectSession(session)}
                  className={cn(
                    'w-full p-3 hover:bg-muted transition-colors flex justify-center',
                    currentSession?.id === session.id && 'bg-primary/10 text-primary'
                  )}
                  title={session.title}
                >
                  <MessageSquare className="w-5 h-5" />
                </button>
              ))}
            </div>
          )}

          {/* Footer */}
          {isOpen && (
            <div className="p-4 border-t border-border">
              <div className="text-xs text-muted-foreground text-center">
                Powered by Embabel 0.3.4
              </div>
            </div>
          )}
        </div>
      </aside>
    </>
  );
}
