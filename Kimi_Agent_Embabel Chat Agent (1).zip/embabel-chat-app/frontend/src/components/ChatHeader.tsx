import { ChatSession } from '@/types';
import { cn } from '@/utils/helpers';
import { 
  Menu, 
  Wifi, 
  WifiOff, 
  Brain, 
  MoreHorizontal,
  Settings,
  Info
} from 'lucide-react';
import { useState } from 'react';

interface ChatHeaderProps {
  session: ChatSession;
  isConnected: boolean;
  showThinking: boolean;
  onToggleThinking: () => void;
  onToggleSidebar: () => void;
}

export function ChatHeader({
  session,
  isConnected,
  showThinking,
  onToggleThinking,
  onToggleSidebar,
}: ChatHeaderProps) {
  const [showMenu, setShowMenu] = useState(false);

  return (
    <header className="h-14 border-b border-border bg-card flex items-center justify-between px-4">
      <div className="flex items-center gap-3">
        <button
          onClick={onToggleSidebar}
          className="p-2 hover:bg-muted rounded-lg transition-colors"
        >
          <Menu className="w-5 h-5" />
        </button>
        
        <div>
          <h1 className="font-semibold text-sm">
            {session.title || 'Untitled Conversation'}
          </h1>
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <span className={cn(
              'flex items-center gap-1',
              isConnected ? 'text-green-500' : 'text-red-500'
            )}>
              {isConnected ? (
                <>
                  <Wifi className="w-3 h-3" />
                  Connected
                </>
              ) : (
                <>
                  <WifiOff className="w-3 h-3" />
                  Disconnected
                </>
              )}
            </span>
            <span>•</span>
            <span>{session.messages?.length || 0} messages</span>
          </div>
        </div>
      </div>

      <div className="flex items-center gap-2">
        {/* Thinking toggle */}
        <button
          onClick={onToggleThinking}
          className={cn(
            'flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm transition-colors',
            showThinking
              ? 'bg-primary/10 text-primary'
              : 'hover:bg-muted text-muted-foreground'
          )}
        >
          <Brain className="w-4 h-4" />
          <span className="hidden sm:inline">Thinking</span>
        </button>

        {/* Menu */}
        <div className="relative">
          <button
            onClick={() => setShowMenu(!showMenu)}
            className="p-2 hover:bg-muted rounded-lg transition-colors"
          >
            <MoreHorizontal className="w-5 h-5" />
          </button>

          {showMenu && (
            <>
              <div 
                className="fixed inset-0 z-40"
                onClick={() => setShowMenu(false)}
              />
              <div className="absolute right-0 top-full mt-1 w-48 bg-card border border-border rounded-lg shadow-lg z-50 py-1">
                <button
                  className="w-full flex items-center gap-2 px-4 py-2 text-sm hover:bg-muted transition-colors"
                  onClick={() => {
                    setShowMenu(false);
                    // TODO: Open settings
                  }}
                >
                  <Settings className="w-4 h-4" />
                  Settings
                </button>
                <button
                  className="w-full flex items-center gap-2 px-4 py-2 text-sm hover:bg-muted transition-colors"
                  onClick={() => {
                    setShowMenu(false);
                    // TODO: Show info
                  }}
                >
                  <Info className="w-4 h-4" />
                  About Embabel
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    </header>
  );
}
