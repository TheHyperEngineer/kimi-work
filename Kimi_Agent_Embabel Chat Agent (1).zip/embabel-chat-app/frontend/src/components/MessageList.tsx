import { useRef, useEffect } from 'react';
import { ChatMessage, ThinkingStep } from '@/types';
import { cn, formatTimestamp } from '@/utils/helpers';
import { User, Bot, Brain, AlertCircle } from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { ChartDisplay } from './ChartDisplay';

interface MessageListProps {
  messages: ChatMessage[];
  isLoading: boolean;
  thinkingSteps: ThinkingStep[];
}

export function MessageList({ messages, isLoading, thinkingSteps }: MessageListProps) {
  const scrollRef = useRef<HTMLDivElement>(null);
  const bottomRef = useRef<HTMLDivElement>(null);

  // Auto-scroll to bottom
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, thinkingSteps]);

  return (
    <div 
      ref={scrollRef}
      className="flex-1 overflow-y-auto p-4 space-y-4"
    >
      {messages.length === 0 ? (
        <div className="flex flex-col items-center justify-center h-full text-center text-muted-foreground">
          <Bot className="w-16 h-16 mb-4 opacity-50" />
          <h3 className="text-lg font-semibold mb-2">Start a conversation</h3>
          <p className="text-sm max-w-md">
            Ask me anything about Embabel, request data visualizations, 
            or query your ingested documents.
          </p>
          <div className="mt-6 flex flex-wrap gap-2 justify-center">
            <SuggestionChip text="What is Embabel?" />
            <SuggestionChip text="Show me a pie chart of sales data" />
            <SuggestionChip text="Compare Embabel with Spring AI" />
          </div>
        </div>
      ) : (
        <>
          {messages.map((message, index) => (
            <MessageItem 
              key={message.id} 
              message={message}
              isLast={index === messages.length - 1}
            />
          ))}
          
          {/* Loading indicator */}
          {isLoading && messages[messages.length - 1]?.role === 'USER' && (
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                <Bot className="w-4 h-4 text-primary" />
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-sm font-medium">Assistant</span>
                </div>
                <div className="flex items-center gap-2 text-muted-foreground">
                  <div className="w-2 h-2 rounded-full bg-primary animate-bounce" />
                  <div className="w-2 h-2 rounded-full bg-primary animate-bounce [animation-delay:0.1s]" />
                  <div className="w-2 h-2 rounded-full bg-primary animate-bounce [animation-delay:0.2s]" />
                  <span className="text-sm ml-2">Thinking...</span>
                </div>
              </div>
            </div>
          )}
          
          <div ref={bottomRef} />
        </>
      )}
    </div>
  );
}

function MessageItem({ message, isLast }: { message: ChatMessage; isLast: boolean }) {
  const isUser = message.role === 'USER';
  const isError = message.type === 'ERROR';
  const isVisualization = message.type === 'VISUALIZATION';

  return (
    <div
      className={cn(
        'flex items-start gap-3 animate-slide-up',
        isUser && 'flex-row-reverse'
      )}
    >
      {/* Avatar */}
      <div
        className={cn(
          'w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0',
          isUser
            ? 'bg-primary'
            : isError
            ? 'bg-destructive/10'
            : 'bg-primary/10'
        )}
      >
        {isUser ? (
          <User className="w-4 h-4 text-primary-foreground" />
        ) : isError ? (
          <AlertCircle className="w-4 h-4 text-destructive" />
        ) : (
          <Bot className="w-4 h-4 text-primary" />
        )}
      </div>

      {/* Message content */}
      <div className={cn('flex-1 max-w-[80%]', isUser && 'text-right')}>
        <div className="flex items-center gap-2 mb-1">
          <span className="text-sm font-medium">
            {isUser ? 'You' : 'Assistant'}
          </span>
          <span className="text-xs text-muted-foreground">
            {formatTimestamp(message.timestamp)}
          </span>
        </div>

        <div
          className={cn(
            'inline-block text-left rounded-2xl px-4 py-3',
            isUser
              ? 'bg-primary text-primary-foreground rounded-br-sm'
              : isError
              ? 'bg-destructive/10 text-destructive border border-destructive/20'
              : 'bg-muted rounded-bl-sm'
          )}
        >
          {isVisualization && message.visualization ? (
            <ChartDisplay data={message.visualization} />
          ) : message.type === 'MARKDOWN' ? (
            <div className="markdown-content prose prose-sm max-w-none dark:prose-invert">
              <ReactMarkdown remarkPlugins={[remarkGfm]}>
                {message.content}
              </ReactMarkdown>
            </div>
          ) : (
            <p className="text-sm whitespace-pre-wrap">{message.content}</p>
          )}
          
          {/* Streaming indicator */}
          {!message.complete && isLast && !isUser && (
            <span className="inline-block w-2 h-4 bg-primary ml-1 animate-pulse" />
          )}
        </div>
      </div>
    </div>
  );
}

function SuggestionChip({ text }: { text: string }) {
  return (
    <button
      className="px-3 py-1.5 bg-muted hover:bg-muted/80 rounded-full text-sm text-muted-foreground transition-colors"
      onClick={() => {
        // This would be handled by the parent component
        const event = new CustomEvent('suggestion-click', { detail: text });
        window.dispatchEvent(event);
      }}
    >
      {text}
    </button>
  );
}
