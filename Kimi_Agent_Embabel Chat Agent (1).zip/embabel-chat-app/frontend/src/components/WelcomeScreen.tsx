import { useState, useEffect } from 'react';
import { chatApi } from '@/services/api';
import { SystemStatus } from '@/types';
import { cn } from '@/utils/helpers';
import { 
  MessageSquare, 
  Brain, 
  BarChart3, 
  FileText, 
  Sparkles,
  ArrowRight,
  CheckCircle2,
  Cpu,
  Shield
} from 'lucide-react';

interface WelcomeScreenProps {
  onStartChat: () => void;
}

export function WelcomeScreen({ onStartChat }: WelcomeScreenProps) {
  const [status, setStatus] = useState<SystemStatus | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadStatus();
  }, []);

  const loadStatus = async () => {
    try {
      const data = await chatApi.getStatus();
      setStatus(data);
    } catch (error) {
      console.error('Failed to load status:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const features = [
    {
      icon: Brain,
      title: 'Multi-Agent Orchestration',
      description: 'Powered by Embabel 0.3.4 with intelligent agent coordination',
    },
    {
      icon: BarChart3,
      title: 'Data Visualizations',
      description: 'Create pie charts, bar charts, and more from your data',
    },
    {
      icon: FileText,
      title: 'Document Q&A',
      description: 'Ask questions about your ingested documents with RAG',
    },
    {
      icon: Sparkles,
      title: 'Streaming Responses',
      description: 'Real-time responses with visible thinking process',
    },
  ];

  const exampleQueries = [
    'What is Embabel and how does it work?',
    'Show me a pie chart of market share data',
    'Compare Embabel with Spring AI and LangGraph',
    'Create a bar chart of monthly sales',
  ];

  return (
    <div className="flex-1 flex flex-col items-center justify-center p-8 overflow-y-auto">
      <div className="max-w-4xl w-full">
        {/* Hero */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center w-20 h-20 rounded-2xl bg-primary/10 mb-6">
            <MessageSquare className="w-10 h-10 text-primary" />
          </div>
          <h1 className="text-4xl font-bold mb-4">
            Welcome to <span className="text-primary">Embabel Chat</span>
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            An AI-powered chat application built with the Embabel Agent Framework. 
            Experience intelligent multi-agent orchestration with real-time streaming 
            and data visualization.
          </p>
        </div>

        {/* Start button */}
        <div className="text-center mb-12">
          <button
            onClick={onStartChat}
            className={cn(
              'inline-flex items-center gap-2 px-8 py-4 rounded-xl',
              'bg-primary text-primary-foreground font-semibold text-lg',
              'hover:bg-primary/90 transition-all transform hover:scale-105',
              'shadow-lg shadow-primary/25'
            )}
          >
            <Sparkles className="w-5 h-5" />
            Start New Conversation
            <ArrowRight className="w-5 h-5" />
          </button>
        </div>

        {/* Features grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-12">
          {features.map((feature, index) => (
            <div
              key={index}
              className={cn(
                'p-6 rounded-xl border border-border bg-card',
                'hover:border-primary/50 hover:shadow-lg transition-all'
              )}
            >
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                  <feature.icon className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <h3 className="font-semibold mb-1">{feature.title}</h3>
                  <p className="text-sm text-muted-foreground">
                    {feature.description}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Example queries */}
        <div className="mb-12">
          <h2 className="text-lg font-semibold mb-4 text-center">Try asking:</h2>
          <div className="flex flex-wrap justify-center gap-2">
            {exampleQueries.map((query, index) => (
              <button
                key={index}
                onClick={() => {
                  onStartChat();
                  // Dispatch event to set the message
                  setTimeout(() => {
                    const event = new CustomEvent('suggestion-click', { detail: query });
                    window.dispatchEvent(event);
                  }, 100);
                }}
                className={cn(
                  'px-4 py-2 rounded-full text-sm',
                  'bg-muted hover:bg-muted/80 text-muted-foreground',
                  'transition-colors'
                )}
              >
                {query}
              </button>
            ))}
          </div>
        </div>

        {/* System status */}
        {!isLoading && status && (
          <div className="border border-border rounded-xl p-6 bg-card">
            <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <Cpu className="w-5 h-5 text-primary" />
              System Status
            </h2>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <StatusItem
                label="Embabel Version"
                value={status.system?.emabelVersion || '0.3.4'}
                icon={CheckCircle2}
              />
              <StatusItem
                label="Active Sessions"
                value={status.sessions?.activeSessions?.toString() || '0'}
                icon={MessageSquare}
              />
              <StatusItem
                label="Vault Mode"
                value={status.vault?.mockMode ? 'Mock' : 'Production'}
                icon={Shield}
              />
              <StatusItem
                label="Status"
                value="Operational"
                icon={CheckCircle2}
                valueClassName="text-green-500"
              />
            </div>
          </div>
        )}

        {/* Footer */}
        <div className="mt-12 text-center text-sm text-muted-foreground">
          <p>
            Built with{' '}
            <a 
              href="https://embabel.com" 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-primary hover:underline"
            >
              Embabel 0.3.4
            </a>
            {' '}• Spring Boot 3.3.5 • React 18
          </p>
        </div>
      </div>
    </div>
  );
}

function StatusItem({ 
  label, 
  value, 
  icon: Icon,
  valueClassName 
}: { 
  label: string; 
  value: string; 
  icon: React.ElementType;
  valueClassName?: string;
}) {
  return (
    <div className="flex items-center gap-3">
      <Icon className="w-4 h-4 text-muted-foreground" />
      <div>
        <div className="text-xs text-muted-foreground">{label}</div>
        <div className={cn('text-sm font-medium', valueClassName)}>{value}</div>
      </div>
    </div>
  );
}
