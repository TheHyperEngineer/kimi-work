import { useState } from 'react';
import { ThinkingStep } from '@/types';
import { cn } from '@/utils/helpers';
import { 
  Brain, 
  ChevronDown, 
  ChevronUp, 
  CheckCircle2, 
  Circle, 
  Loader2,
  XCircle,
  Lightbulb,
  Search,
  Wrench,
  FileSearch
} from 'lucide-react';

interface ThinkingPanelProps {
  steps: ThinkingStep[];
  isActive: boolean;
}

const stepIcons: Record<string, React.ElementType> = {
  ANALYSIS: Brain,
  PLANNING: Lightbulb,
  RESEARCH: Search,
  REASONING: Brain,
  TOOL_SELECTION: Wrench,
  EXECUTION: Loader2,
  REVIEW: FileSearch,
  FINALIZING: CheckCircle2,
};

const stepColors: Record<string, string> = {
  PENDING: 'text-muted-foreground',
  IN_PROGRESS: 'text-primary',
  COMPLETED: 'text-green-500',
  FAILED: 'text-destructive',
  SKIPPED: 'text-muted-foreground',
};

export function ThinkingPanel({ steps, isActive }: ThinkingPanelProps) {
  const [isExpanded, setIsExpanded] = useState(true);
  const [expandedSteps, setExpandedSteps] = useState<Set<string>>(new Set());

  const toggleStep = (stepId: string) => {
    const newExpanded = new Set(expandedSteps);
    if (newExpanded.has(stepId)) {
      newExpanded.delete(stepId);
    } else {
      newExpanded.add(stepId);
    }
    setExpandedSteps(newExpanded);
  };

  if (steps.length === 0 && !isActive) {
    return null;
  }

  return (
    <div className="w-80 border-l border-border bg-card flex flex-col">
      {/* Header */}
      <div 
        className="h-14 border-b border-border flex items-center justify-between px-4 cursor-pointer hover:bg-muted/50 transition-colors"
        onClick={() => setIsExpanded(!isExpanded)}
      >
        <div className="flex items-center gap-2">
          <Brain className="w-5 h-5 text-primary" />
          <span className="font-semibold text-sm">Thinking Process</span>
        </div>
        <div className="flex items-center gap-2">
          {isActive && (
            <Loader2 className="w-4 h-4 animate-spin text-primary" />
          )}
          {isExpanded ? (
            <ChevronDown className="w-4 h-4" />
          ) : (
            <ChevronUp className="w-4 h-4" />
          )}
        </div>
      </div>

      {/* Content */}
      {isExpanded && (
        <div className="flex-1 overflow-y-auto p-4">
          {steps.length === 0 && isActive ? (
            <div className="flex flex-col items-center justify-center h-32 text-muted-foreground">
              <Loader2 className="w-8 h-8 animate-spin mb-2" />
              <p className="text-sm">Analyzing your request...</p>
            </div>
          ) : (
            <div className="space-y-3">
              {steps.map((step, index) => {
                const Icon = stepIcons[step.type] || Circle;
                const isExpandedStep = expandedSteps.has(step.stepId);

                return (
                  <div
                    key={step.stepId}
                    className={cn(
                      'border rounded-lg overflow-hidden transition-all',
                      step.status === 'IN_PROGRESS' && 'border-primary/50 bg-primary/5',
                      step.status === 'COMPLETED' && 'border-green-500/30 bg-green-500/5',
                      step.status === 'FAILED' && 'border-destructive/30 bg-destructive/5'
                    )}
                  >
                    {/* Step header */}
                    <button
                      onClick={() => toggleStep(step.stepId)}
                      className="w-full flex items-center gap-3 p-3 text-left hover:bg-muted/50 transition-colors"
                    >
                      <div className={cn('flex-shrink-0', stepColors[step.status])}>
                        {step.status === 'IN_PROGRESS' ? (
                          <Loader2 className="w-4 h-4 animate-spin" />
                        ) : step.status === 'COMPLETED' ? (
                          <CheckCircle2 className="w-4 h-4" />
                        ) : step.status === 'FAILED' ? (
                          <XCircle className="w-4 h-4" />
                        ) : (
                          <Icon className="w-4 h-4" />
                        )}
                      </div>
                      
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-medium text-muted-foreground">
                            {index + 1}.
                          </span>
                          <span className="text-sm font-medium truncate">
                            {step.title}
                          </span>
                        </div>
                        <p className="text-xs text-muted-foreground truncate">
                          {step.description}
                        </p>
                      </div>

                      {step.reasoning && step.reasoning.length > 0 && (
                        <ChevronDown 
                          className={cn(
                            'w-4 h-4 text-muted-foreground transition-transform',
                            isExpandedStep && 'rotate-180'
                          )} 
                        />
                      )}
                    </button>

                    {/* Expanded content */}
                    {isExpandedStep && step.reasoning && step.reasoning.length > 0 && (
                      <div className="px-3 pb-3 border-t border-border/50">
                        <div className="pt-2 space-y-2">
                          <div>
                            <span className="text-xs font-medium text-muted-foreground uppercase">
                              Reasoning
                            </span>
                            <ul className="mt-1 space-y-1">
                              {step.reasoning.map((reason, i) => (
                                <li 
                                  key={i}
                                  className="text-xs text-muted-foreground pl-3 border-l-2 border-border"
                                >
                                  {reason}
                                </li>
                              ))}
                            </ul>
                          </div>

                          {step.considerations && step.considerations.length > 0 && (
                            <div>
                              <span className="text-xs font-medium text-muted-foreground uppercase">
                                Considerations
                              </span>
                              <ul className="mt-1 space-y-1">
                                {step.considerations.map((consideration, i) => (
                                  <li 
                                    key={i}
                                    className="text-xs text-muted-foreground pl-3 border-l-2 border-border"
                                  >
                                    {consideration}
                                  </li>
                                ))}
                              </ul>
                            </div>
                          )}

                          {step.decision && (
                            <div>
                              <span className="text-xs font-medium text-muted-foreground uppercase">
                                Decision
                              </span>
                              <p className="mt-1 text-xs text-foreground pl-3 border-l-2 border-primary">
                                {step.decision}
                              </p>
                            </div>
                          )}

                          {step.durationMs && (
                            <div className="text-xs text-muted-foreground">
                              Duration: {(step.durationMs / 1000).toFixed(2)}s
                            </div>
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
