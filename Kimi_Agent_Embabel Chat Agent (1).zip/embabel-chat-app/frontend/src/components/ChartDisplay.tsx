import { useRef, useEffect } from 'react';
import { VisualizationData } from '@/types';
import {
  Chart as ChartJS,
  ArcElement,
  BarElement,
  LineElement,
  PointElement,
  CategoryScale,
  LinearScale,
  RadialLinearScale,
  Title,
  Tooltip,
  Legend,
  Filler,
  ChartData,
  ChartOptions,
} from 'chart.js';
import { Pie, Bar, Line, Doughnut } from 'react-chartjs-2';
import { cn } from '@/utils/helpers';
import { Download, Maximize2 } from 'lucide-react';

// Register Chart.js components
ChartJS.register(
  ArcElement,
  BarElement,
  LineElement,
  PointElement,
  CategoryScale,
  LinearScale,
  RadialLinearScale,
  Title,
  Tooltip,
  Legend,
  Filler
);

interface ChartDisplayProps {
  data: VisualizationData;
  className?: string;
}

export function ChartDisplay({ data, className }: ChartDisplayProps) {
  const chartRef = useRef<ChartJS | null>(null);

  const handleDownload = () => {
    const chart = chartRef.current;
    if (chart) {
      const url = chart.toBase64Image();
      const link = document.createElement('a');
      link.download = `${data.title || 'chart'}.png`;
      link.href = url;
      link.click();
    }
  };

  const renderChart = () => {
    const commonOptions: ChartOptions<'pie' | 'bar' | 'line' | 'doughnut'> = {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          display: data.options?.legend !== false,
          position: data.options?.legendPosition || 'bottom',
        },
        tooltip: {
          enabled: data.options?.tooltips !== false,
        },
        title: {
          display: !!data.title,
          text: data.title,
        },
      },
      animation: {
        duration: data.options?.animation !== false ? 1000 : 0,
      },
    };

    switch (data.type) {
      case 'PIE':
        return (
          <Pie
            ref={chartRef as any}
            data={createPieData(data)}
            options={commonOptions as ChartOptions<'pie'>}
          />
        );

      case 'DOUGHNUT':
        return (
          <Doughnut
            ref={chartRef as any}
            data={createPieData(data)}
            options={commonOptions as ChartOptions<'doughnut'>}
          />
        );

      case 'BAR':
      case 'HORIZONTAL_BAR':
        return (
          <Bar
            ref={chartRef as any}
            data={createBarData(data)}
            options={{
              ...commonOptions,
              indexAxis: data.type === 'HORIZONTAL_BAR' ? 'y' : 'x',
              scales: {
                x: {
                  title: {
                    display: !!data.xAxis?.title,
                    text: data.xAxis?.title,
                  },
                  grid: {
                    display: data.xAxis?.gridLines,
                  },
                },
                y: {
                  title: {
                    display: !!data.yAxis?.title,
                    text: data.yAxis?.title,
                  },
                  grid: {
                    display: data.yAxis?.gridLines,
                  },
                },
              },
            } as ChartOptions<'bar'>}
          />
        );

      case 'LINE':
      case 'AREA':
        return (
          <Line
            ref={chartRef as any}
            data={createLineData(data)}
            options={{
              ...commonOptions,
              elements: {
                line: {
                  fill: data.type === 'AREA',
                },
              },
              scales: {
                x: {
                  title: {
                    display: !!data.xAxis?.title,
                    text: data.xAxis?.title,
                  },
                },
                y: {
                  title: {
                    display: !!data.yAxis?.title,
                    text: data.yAxis?.title,
                  },
                },
              },
            } as ChartOptions<'line'>}
          />
        );

      default:
        return (
          <div className="flex items-center justify-center h-64 text-muted-foreground">
            Unsupported chart type: {data.type}
          </div>
        );
    }
  };

  return (
    <div className={cn('bg-card border border-border rounded-lg p-4', className)}>
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <div>
          <h3 className="font-semibold text-lg">{data.title}</h3>
          {data.description && (
            <p className="text-sm text-muted-foreground">{data.description}</p>
          )}
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={handleDownload}
            className="p-2 hover:bg-muted rounded-lg transition-colors"
            title="Download chart"
          >
            <Download className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Chart */}
      <div 
        className="relative"
        style={{ height: data.options?.height || 300 }}
      >
        {renderChart()}
      </div>

      {/* Source */}
      {data.source && (
        <div className="mt-4 text-xs text-muted-foreground">
          Source: {data.source}
        </div>
      )}
    </div>
  );
}

// Helper functions to create Chart.js data
function createPieData(data: VisualizationData): ChartData<'pie'> {
  const colors = data.data?.map((d, i) => d.color) || getDefaultColors(data.data?.length || 0);
  
  return {
    labels: data.data?.map((d) => d.label) || [],
    datasets: [
      {
        data: data.data?.map((d) => d.value) || [],
        backgroundColor: colors,
        borderColor: colors.map((c) => c.replace('0.8', '1')),
        borderWidth: 1,
      },
    ],
  };
}

function createBarData(data: VisualizationData): ChartData<'bar'> {
  const colors = getDefaultColors(data.series?.length || 1);
  
  if (data.series && data.series.length > 0) {
    return {
      labels: data.xAxis?.categories || data.data?.map((d) => d.label) || [],
      datasets: data.series.map((series, i) => ({
        label: series.name,
        data: series.data,
        backgroundColor: series.color || colors[i],
        borderColor: series.color || colors[i],
        borderWidth: 1,
      })),
    };
  }

  return {
    labels: data.data?.map((d) => d.label) || [],
    datasets: [
      {
        label: 'Values',
        data: data.data?.map((d) => d.value) || [],
        backgroundColor: colors[0],
        borderColor: colors[0],
        borderWidth: 1,
      },
    ],
  };
}

function createLineData(data: VisualizationData): ChartData<'line'> {
  const colors = getDefaultColors(data.series?.length || 1);
  
  if (data.series && data.series.length > 0) {
    return {
      labels: data.xAxis?.categories || data.data?.map((d) => d.label) || [],
      datasets: data.series.map((series, i) => ({
        label: series.name,
        data: series.data,
        borderColor: series.color || colors[i],
        backgroundColor: (series.color || colors[i]).replace('1)', '0.1)'),
        fill: data.type === 'AREA',
        tension: 0.4,
      })),
    };
  }

  return {
    labels: data.data?.map((d) => d.label) || [],
    datasets: [
      {
        label: 'Values',
        data: data.data?.map((d) => d.value) || [],
        borderColor: colors[0],
        backgroundColor: colors[0].replace('1)', '0.1)'),
        fill: data.type === 'AREA',
        tension: 0.4,
      },
    ],
  };
}

function getDefaultColors(count: number): string[] {
  const palette = [
    'rgba(255, 99, 132, 0.8)',
    'rgba(54, 162, 235, 0.8)',
    'rgba(255, 206, 86, 0.8)',
    'rgba(75, 192, 192, 0.8)',
    'rgba(153, 102, 255, 0.8)',
    'rgba(255, 159, 64, 0.8)',
    'rgba(199, 199, 199, 0.8)',
    'rgba(83, 102, 255, 0.8)',
    'rgba(40, 159, 64, 0.8)',
    'rgba(215, 99, 132, 0.8)',
  ];

  const colors: string[] = [];
  for (let i = 0; i < count; i++) {
    colors.push(palette[i % palette.length]);
  }
  return colors;
}
