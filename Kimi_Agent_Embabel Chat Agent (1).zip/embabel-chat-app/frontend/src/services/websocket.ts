import { Client, IMessage, StompSubscription } from '@stomp/stompjs';
import SockJS from 'sockjs-client';
import { ChatResponse, ChatMessage } from '@/types';

export type MessageHandler = (message: ChatResponse) => void;
export type ConnectionHandler = (connected: boolean) => void;

export class WebSocketService {
  private client: Client | null = null;
  private subscriptions: Map<string, StompSubscription> = new Map();
  private messageHandlers: Map<string, MessageHandler[]> = new Map();
  private connectionHandlers: ConnectionHandler[] = [];
  private reconnectAttempts = 0;
  private maxReconnectAttempts = 5;

  connect(): void {
    if (this.client?.active) {
      return;
    }

    this.client = new Client({
      webSocketFactory: () => new SockJS('/ws/chat'),
      reconnectDelay: 5000,
      heartbeatIncoming: 4000,
      heartbeatOutgoing: 4000,
      onConnect: () => {
        console.log('WebSocket connected');
        this.reconnectAttempts = 0;
        this.notifyConnectionHandlers(true);
      },
      onDisconnect: () => {
        console.log('WebSocket disconnected');
        this.notifyConnectionHandlers(false);
      },
      onStompError: (frame) => {
        console.error('STOMP error:', frame);
        this.reconnectAttempts++;
        if (this.reconnectAttempts >= this.maxReconnectAttempts) {
          this.disconnect();
        }
      },
    });

    this.client.activate();
  }

  disconnect(): void {
    this.subscriptions.forEach((sub) => sub.unsubscribe());
    this.subscriptions.clear();
    this.client?.deactivate();
    this.client = null;
  }

  subscribeToConversation(conversationId: string, handler: MessageHandler): void {
    if (!this.client?.active) {
      console.warn('WebSocket not connected');
      return;
    }

    const topic = `/topic/chat/${conversationId}`;
    
    if (!this.subscriptions.has(topic)) {
      const subscription = this.client.subscribe(topic, (message: IMessage) => {
        try {
          const data: ChatResponse = JSON.parse(message.body);
          this.notifyMessageHandlers(conversationId, data);
        } catch (error) {
          console.error('Error parsing message:', error);
        }
      });
      
      this.subscriptions.set(topic, subscription);
      this.messageHandlers.set(conversationId, []);
    }

    const handlers = this.messageHandlers.get(conversationId) || [];
    handlers.push(handler);
    this.messageHandlers.set(conversationId, handlers);
  }

  subscribeToThinking(conversationId: string, handler: MessageHandler): void {
    if (!this.client?.active) {
      console.warn('WebSocket not connected');
      return;
    }

    const topic = `/topic/thinking/${conversationId}`;
    
    if (!this.subscriptions.has(topic)) {
      const subscription = this.client.subscribe(topic, (message: IMessage) => {
        try {
          const data: ChatResponse = JSON.parse(message.body);
          this.notifyMessageHandlers(`thinking-${conversationId}`, data);
        } catch (error) {
          console.error('Error parsing message:', error);
        }
      });
      
      this.subscriptions.set(topic, subscription);
      this.messageHandlers.set(`thinking-${conversationId}`, []);
    }

    const handlers = this.messageHandlers.get(`thinking-${conversationId}`) || [];
    handlers.push(handler);
    this.messageHandlers.set(`thinking-${conversationId}`, handlers);
  }

  unsubscribeFromConversation(conversationId: string, handler?: MessageHandler): void {
    const topic = `/topic/chat/${conversationId}`;
    const thinkingTopic = `/topic/thinking/${conversationId}`;

    if (handler) {
      // Remove specific handler
      const handlers = this.messageHandlers.get(conversationId) || [];
      const index = handlers.indexOf(handler);
      if (index > -1) {
        handlers.splice(index, 1);
      }

      const thinkingHandlers = this.messageHandlers.get(`thinking-${conversationId}`) || [];
      const thinkingIndex = thinkingHandlers.indexOf(handler);
      if (thinkingIndex > -1) {
        thinkingHandlers.splice(thinkingIndex, 1);
      }
    } else {
      // Remove all handlers and unsubscribe
      this.subscriptions.get(topic)?.unsubscribe();
      this.subscriptions.delete(topic);
      this.messageHandlers.delete(conversationId);

      this.subscriptions.get(thinkingTopic)?.unsubscribe();
      this.subscriptions.delete(thinkingTopic);
      this.messageHandlers.delete(`thinking-${conversationId}`);
    }
  }

  sendMessage(conversationId: string, message: string, showThinking: boolean = true): void {
    if (!this.client?.active) {
      console.warn('WebSocket not connected');
      return;
    }

    this.client.publish({
      destination: '/app/chat.sendMessage',
      body: JSON.stringify({
        message,
        conversationId,
        showThinking,
        streamResponse: true,
      }),
    });
  }

  sendTypingIndicator(conversationId: string, isTyping: boolean): void {
    if (!this.client?.active) {
      return;
    }

    this.client.publish({
      destination: '/app/chat.typing',
      body: JSON.stringify({
        conversationId,
        typing: isTyping,
      }),
    });
  }

  onConnectionChange(handler: ConnectionHandler): () => void {
    this.connectionHandlers.push(handler);
    return () => {
      const index = this.connectionHandlers.indexOf(handler);
      if (index > -1) {
        this.connectionHandlers.splice(index, 1);
      }
    };
  }

  isConnected(): boolean {
    return this.client?.active ?? false;
  }

  private notifyMessageHandlers(conversationId: string, data: ChatResponse): void {
    const handlers = this.messageHandlers.get(conversationId) || [];
    handlers.forEach((handler) => {
      try {
        handler(data);
      } catch (error) {
        console.error('Error in message handler:', error);
      }
    });
  }

  private notifyConnectionHandlers(connected: boolean): void {
    this.connectionHandlers.forEach((handler) => {
      try {
        handler(connected);
      } catch (error) {
        console.error('Error in connection handler:', error);
      }
    });
  }
}

export const websocketService = new WebSocketService();
export default websocketService;
