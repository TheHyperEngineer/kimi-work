import axios from 'axios';
import { ChatSession, ChatMessage, DocumentInfo, DocumentSearchResult, SystemStatus } from '@/types';

const API_BASE_URL = '/api/chat';

const apiClient = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

export const chatApi = {
  // Session management
  createSession: async (userId?: string, title?: string): Promise<ChatSession> => {
    const params = new URLSearchParams();
    if (userId) params.append('userId', userId);
    if (title) params.append('title', title);
    
    const response = await apiClient.post(`/sessions?${params}`);
    return response.data;
  },

  getSession: async (sessionId: string): Promise<ChatSession | null> => {
    try {
      const response = await apiClient.get(`/sessions/${sessionId}`);
      return response.data;
    } catch {
      return null;
    }
  },

  getUserSessions: async (userId?: string): Promise<ChatSession[]> => {
    const params = userId ? `?userId=${userId}` : '';
    const response = await apiClient.get(`/sessions${params}`);
    return response.data;
  },

  deleteSession: async (sessionId: string): Promise<boolean> => {
    try {
      await apiClient.delete(`/sessions/${sessionId}`);
      return true;
    } catch {
      return false;
    }
  },

  updateSessionTitle: async (sessionId: string, title: string): Promise<void> => {
    await apiClient.put(`/sessions/${sessionId}/title`, title);
  },

  // Messages
  getSessionMessages: async (sessionId: string, limit: number = 50): Promise<ChatMessage[]> => {
    const response = await apiClient.get(`/sessions/${sessionId}/messages?limit=${limit}`);
    return response.data;
  },

  sendMessage: async (sessionId: string, message: string): Promise<ChatMessage> => {
    const response = await apiClient.post(`/sessions/${sessionId}/messages`, {
      message,
      type: 'CHAT',
    });
    return response.data;
  },

  // Documents
  getDocuments: async (): Promise<DocumentInfo[]> => {
    const response = await apiClient.get('/documents');
    return response.data;
  },

  ingestDocument: async (filePath: string): Promise<{ documentId: string; success: boolean }> => {
    const response = await apiClient.post(`/documents?filePath=${encodeURIComponent(filePath)}`);
    return response.data;
  },

  searchDocuments: async (query: string): Promise<DocumentSearchResult[]> => {
    const response = await apiClient.get(`/documents/search?query=${encodeURIComponent(query)}`);
    return response.data;
  },

  getDocumentStatistics: async (): Promise<{
    totalDocuments: number;
    ingestedDocuments: number;
    failedDocuments: number;
    totalChunks: number;
    indexedDocuments: number;
  }> => {
    const response = await apiClient.get('/documents/statistics');
    return response.data;
  },

  // System
  getStatus: async (): Promise<SystemStatus> => {
    const response = await apiClient.get('/status');
    return response.data;
  },

  getVisualizationTypes: async (): Promise<{ id: string; name: string; description: string }[]> => {
    const response = await apiClient.get('/visualizations/types');
    return response.data;
  },
};

export default apiClient;
