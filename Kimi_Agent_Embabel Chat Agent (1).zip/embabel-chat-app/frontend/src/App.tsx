import { useState, useEffect, useCallback } from 'react';
import { ChatSession, ChatMessage } from '@/types';
import { chatApi } from '@/services/api';
import { websocketService } from '@/services/websocket';
import { Sidebar } from '@/components/Sidebar';
import { ChatHeader } from '@/components/ChatHeader';
import { MessageList } from '@/components/MessageList';
import { MessageInput } from '@/components/MessageInput';
import { ThinkingPanel } from '@/components/ThinkingPanel';
import { WelcomeScreen } from '@/components/WelcomeScreen';
import { generateId } from '@/utils/helpers';

function App() {
  const [sessions, setSessions] = useState<ChatSession[]>([]);
  const [currentSession, setCurrentSession] = useState<ChatSession | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [showThinking, setShowThinking] = useState(true);
  const [thinkingSteps, setThinkingSteps] = useState<any[]>([]);
  const [isConnected, setIsConnected] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(true);

  // Initialize WebSocket connection
  useEffect(() => {
    websocketService.connect();
    
    const unsubscribe = websocketService.onConnectionChange((connected) => {
      setIsConnected(connected);
    });

    return () => {
      unsubscribe();
      websocketService.disconnect();
    };
  }, []);

  // Load sessions on mount
  useEffect(() => {
    loadSessions();
  }, []);

  // Subscribe to current session messages
  useEffect(() => {
    if (!currentSession) return;

    const handleMessage = (response: any) => {
      if (response.type === 'THINKING_UPDATE' && response.currentThinkingStep) {
        setThinkingSteps((prev) => {
          const exists = prev.find(s => s.stepId === response.currentThinkingStep.stepId);
          if (exists) {
            return prev.map(s => s.stepId === response.currentThinkingStep.stepId 
              ? response.currentThinkingStep : s);
          }
          return [...prev, response.currentThinkingStep];
        });
      } else if (response.type === 'THINKING_COMPLETE') {
        setThinkingSteps(response.thinkingSteps || []);
      } else if (response.type === 'CONTENT_CHUNK') {
        setMessages((prev) => {
          const lastMessage = prev[prev.length - 1];
          if (lastMessage && lastMessage.role === 'ASSISTANT' && !lastMessage.complete) {
            const updated = [...prev];
            updated[updated.length - 1] = {
              ...lastMessage,
              content: lastMessage.content + (response.content || ''),
            };
            return updated;
          }
          return [...prev, {
            id: generateId(),
            conversationId: currentSession.id,
            role: 'ASSISTANT',
            type: 'TEXT',
            content: response.content || '',
            timestamp: new Date().toISOString(),
            complete: false,
          }];
        });
      } else if (response.type === 'CONTENT_COMPLETE') {
        setMessages((prev) => {
          const lastMessage = prev[prev.length - 1];
          if (lastMessage && lastMessage.role === 'ASSISTANT') {
            const updated = [...prev];
            updated[updated.length - 1] = {
              ...lastMessage,
              content: response.content || lastMessage.content,
              complete: true,
            };
            return updated;
          }
          return prev;
        });
        setIsLoading(false);
      } else if (response.type === 'VISUALIZATION' && response.visualization) {
        setMessages((prev) => [...prev, {
          id: generateId(),
          conversationId: currentSession.id,
          role: 'ASSISTANT',
          type: 'VISUALIZATION',
          content: response.visualization?.description || '',
          visualization: response.visualization,
          timestamp: new Date().toISOString(),
          complete: true,
        }]);
      } else if (response.type === 'ERROR') {
        setMessages((prev) => [...prev, {
          id: generateId(),
          conversationId: currentSession.id,
          role: 'ASSISTANT',
          type: 'ERROR',
          content: response.error?.message || 'An error occurred',
          timestamp: new Date().toISOString(),
          complete: true,
        }]);
        setIsLoading(false);
      }
    };

    websocketService.subscribeToConversation(currentSession.id, handleMessage);
    if (showThinking) {
      websocketService.subscribeToThinking(currentSession.id, handleMessage);
    }

    return () => {
      websocketService.unsubscribeFromConversation(currentSession.id, handleMessage);
    };
  }, [currentSession, showThinking]);

  const loadSessions = async () => {
    try {
      const data = await chatApi.getUserSessions();
      setSessions(data);
    } catch (error) {
      console.error('Failed to load sessions:', error);
    }
  };

  const createNewSession = async () => {
    try {
      const session = await chatApi.createSession(undefined, 'New Conversation');
      setSessions((prev) => [session, ...prev]);
      setCurrentSession(session);
      setMessages([]);
      setThinkingSteps([]);
    } catch (error) {
      console.error('Failed to create session:', error);
    }
  };

  const selectSession = async (session: ChatSession) => {
    setCurrentSession(session);
    setThinkingSteps([]);
    try {
      const msgs = await chatApi.getSessionMessages(session.id, 50);
      setMessages(msgs);
    } catch (error) {
      console.error('Failed to load messages:', error);
      setMessages([]);
    }
  };

  const deleteSession = async (sessionId: string) => {
    try {
      await chatApi.deleteSession(sessionId);
      setSessions((prev) => prev.filter((s) => s.id !== sessionId));
      if (currentSession?.id === sessionId) {
        setCurrentSession(null);
        setMessages([]);
      }
    } catch (error) {
      console.error('Failed to delete session:', error);
    }
  };

  const sendMessage = useCallback(async (content: string) => {
    if (!content.trim()) return;

    // Create session if none exists
    let session = currentSession;
    if (!session) {
      try {
        session = await chatApi.createSession(undefined, 'New Conversation');
        setSessions((prev) => [session!, ...prev]);
        setCurrentSession(session);
      } catch (error) {
        console.error('Failed to create session:', error);
        return;
      }
    }

    // Add user message
    const userMessage: ChatMessage = {
      id: generateId(),
      conversationId: session.id,
      role: 'USER',
      type: 'TEXT',
      content,
      timestamp: new Date().toISOString(),
      complete: true,
    };

    setMessages((prev) => [...prev, userMessage]);
    setIsLoading(true);
    setThinkingSteps([]);

    // Send via WebSocket
    websocketService.sendMessage(session.id, content, showThinking);
  }, [currentSession, showThinking]);

  return (
    <div className="flex h-screen bg-background">
      {/* Sidebar */}
      <Sidebar
        sessions={sessions}
        currentSession={currentSession}
        onSelectSession={selectSession}
        onCreateSession={createNewSession}
        onDeleteSession={deleteSession}
        isOpen={sidebarOpen}
        onToggle={() => setSidebarOpen(!sidebarOpen)}
      />

      {/* Main content */}
      <div className="flex-1 flex flex-col min-w-0">
        {currentSession ? (
          <>
            <ChatHeader
              session={currentSession}
              isConnected={isConnected}
              showThinking={showThinking}
              onToggleThinking={() => setShowThinking(!showThinking)}
              onToggleSidebar={() => setSidebarOpen(!sidebarOpen)}
            />

            <div className="flex-1 flex overflow-hidden">
              {/* Messages area */}
              <div className="flex-1 flex flex-col min-w-0">
                <MessageList
                  messages={messages}
                  isLoading={isLoading}
                  thinkingSteps={thinkingSteps}
                />
                <MessageInput
                  onSend={sendMessage}
                  disabled={isLoading}
                  placeholder="Type your message..."
                />
              </div>

              {/* Thinking panel */}
              {showThinking && (
                <ThinkingPanel
                  steps={thinkingSteps}
                  isActive={isLoading}
                />
              )}
            </div>
          </>
        ) : (
          <WelcomeScreen onStartChat={createNewSession} />
        )}
      </div>
    </div>
  );
}

export default App;
