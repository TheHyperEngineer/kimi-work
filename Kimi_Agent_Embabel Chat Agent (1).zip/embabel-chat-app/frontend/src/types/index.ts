export interface ChatMessage {
  id: string;
  conversationId: string;
  role: 'USER' | 'ASSISTANT' | 'SYSTEM' | 'THINKING' | 'TOOL';
  content: string;
  type: 'TEXT' | 'MARKDOWN' | 'VISUALIZATION' | 'CODE' | 'ERROR' | 'THINKING' | 'TOOL_RESULT';
  timestamp: string;
  agentName?: string;
  thinkingStep?: ThinkingStep;
  visualization?: VisualizationData;
  metadata?: Record<string, unknown>;
  streaming?: boolean;
  complete?: boolean;
}

export interface ThinkingStep {
  stepId: string;
  type: 'ANALYSIS' | 'PLANNING' | 'RESEARCH' | 'REASONING' | 'TOOL_SELECTION' | 'EXECUTION' | 'REVIEW' | 'FINALIZING';
  title: string;
  description: string;
  order: number;
  startedAt: string;
  completedAt?: string;
  durationMs?: number;
  reasoning?: string[];
  considerations?: string[];
  decision?: string;
  confidence?: number;
  subSteps?: ThinkingStep[];
  toolsUsed?: ToolUsage[];
  status: 'PENDING' | 'IN_PROGRESS' | 'COMPLETED' | 'FAILED' | 'SKIPPED';
}

export interface ToolUsage {
  toolName: string;
  description: string;
  parameters: Record<string, unknown>;
  result?: unknown;
  success: boolean;
  executionTimeMs: number;
}

export interface VisualizationData {
  id: string;
  type: 'PIE' | 'DOUGHNUT' | 'BAR' | 'HORIZONTAL_BAR' | 'LINE' | 'AREA' | 'SCATTER' | 'RADAR' | 'POLAR_AREA';
  title: string;
  description?: string;
  source?: string;
  data?: DataPoint[];
  series?: DataSeries[];
  xAxis?: AxisConfig;
  yAxis?: AxisConfig;
  options?: ChartOptions;
  rawData?: Record<string, unknown>;
}

export interface DataPoint {
  label: string;
  value: number;
  color?: string;
  metadata?: Record<string, unknown>;
}

export interface DataSeries {
  name: string;
  color?: string;
  data: number[];
  metadata?: Record<string, unknown>;
}

export interface AxisConfig {
  title?: string;
  type?: string;
  categories?: string[];
  min?: number;
  max?: number;
  gridLines?: boolean;
}

export interface ChartOptions {
  legend?: boolean;
  legendPosition?: 'top' | 'bottom' | 'left' | 'right';
  tooltips?: boolean;
  animation?: boolean;
  responsive?: boolean;
  height?: number;
  width?: number;
  additionalOptions?: Record<string, unknown>;
}

export interface ChatSession {
  id: string;
  userId?: string;
  title: string;
  status: 'ACTIVE' | 'PAUSED' | 'ENDED' | 'EXPIRED';
  messages: ChatMessage[];
  createdAt: string;
  lastActivityAt: string;
  endedAt?: string;
  context?: Record<string, unknown>;
  documentIds?: string[];
  metadata?: SessionMetadata;
  currentAgentProcessId?: string;
  agentStatus: 'IDLE' | 'THINKING' | 'PLANNING' | 'EXECUTING' | 'RESPONDING' | 'TOOL_EXECUTING';
}

export interface SessionMetadata {
  userAgent?: string;
  ipAddress?: string;
  source?: string;
  customData?: Record<string, unknown>;
}

export interface ChatRequest {
  message: string;
  conversationId?: string;
  userId?: string;
  type?: 'CHAT' | 'DOCUMENT_QUERY' | 'VISUALIZATION' | 'SYSTEM';
  stream?: boolean;
  showThinking?: boolean;
  visualization?: 'AUTO' | 'PIE_CHART' | 'BAR_CHART' | 'LINE_CHART' | 'TABLE';
  documentIds?: string[];
  context?: Record<string, unknown>;
}

export interface ChatResponse {
  id: string;
  conversationId: string;
  type: 'THINKING_START' | 'THINKING_UPDATE' | 'THINKING_COMPLETE' | 'CONTENT_CHUNK' | 'CONTENT_COMPLETE' | 'VISUALIZATION' | 'TOOL_RESULT' | 'ERROR' | 'SYSTEM';
  content?: string;
  status: 'SUCCESS' | 'PARTIAL' | 'ERROR' | 'CANCELLED' | 'TIMEOUT';
  timestamp: string;
  thinkingSteps?: ThinkingStep[];
  currentThinkingStep?: ThinkingStep;
  visualization?: VisualizationData;
  relatedMessages?: ChatMessage[];
  agentName?: string;
  finalChunk?: boolean;
  chunkNumber?: number;
  error?: ErrorInfo;
  metadata?: Record<string, unknown>;
}

export interface ErrorInfo {
  code: string;
  message: string;
  details?: string;
  retryable: boolean;
}

export interface DocumentInfo {
  documentId: string;
  filename: string;
  filePath: string;
  contentType: string;
  fileSize: number;
  chunkCount: number;
  ingestedAt: string;
  status: 'PENDING' | 'PROCESSING' | 'INGESTED' | 'FAILED' | 'REMOVED';
  metadata?: Record<string, unknown>;
}

export interface DocumentSearchResult {
  documentId: string;
  content: string;
  score: number;
  metadata?: Record<string, unknown>;
}

export interface SystemStatus {
  sessions: {
    totalSessions: number;
    activeSessions: number;
    hitRate: number;
    missRate: number;
    evictionCount: number;
  };
  vault: {
    mockMode: boolean;
    secretCount: number;
    lastRefresh?: string;
    nextRefresh?: string;
  };
  system: {
    version: string;
    embabelVersion: string;
    timestamp: string;
  };
}
