#!/bin/bash

# Embabel Chat Application - Quick Start Script
# This script starts both the backend and frontend servers

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${BLUE}=======================================${NC}"
echo -e "${BLUE}  Embabel Chat Application Starter    ${NC}"
echo -e "${BLUE}=======================================${NC}"
echo ""

# Check prerequisites
check_prerequisite() {
    if ! command -v $1 &> /dev/null; then
        echo -e "${RED}Error: $1 is not installed${NC}"
        return 1
    fi
    return 0
}

echo -e "${YELLOW}Checking prerequisites...${NC}"

if ! check_prerequisite "java"; then
    echo "Please install Java 21 or higher: https://adoptium.net/"
    exit 1
fi

if ! check_prerequisite "mvn"; then
    echo "Please install Maven: https://maven.apache.org/download.cgi"
    exit 1
fi

if ! check_prerequisite "node"; then
    echo "Please install Node.js 18 or higher: https://nodejs.org/"
    exit 1
fi

if ! check_prerequisite "npm"; then
    echo "Please install npm"
    exit 1
fi

echo -e "${GREEN}All prerequisites met!${NC}"
echo ""

# Get script directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

# Function to cleanup processes on exit
cleanup() {
    echo ""
    echo -e "${YELLOW}Shutting down servers...${NC}"
    if [ -n "$BACKEND_PID" ]; then
        kill $BACKEND_PID 2>/dev/null || true
    fi
    if [ -n "$FRONTEND_PID" ]; then
        kill $FRONTEND_PID 2>/dev/null || true
    fi
    echo -e "${GREEN}Goodbye!${NC}"
    exit 0
}

trap cleanup INT TERM

# Start Backend
echo -e "${BLUE}Starting Backend Server...${NC}"
cd backend

# Check if Maven wrapper exists, if not use system mvn
if [ -f "./mvnw" ]; then
    MVN_CMD="./mvnw"
else
    MVN_CMD="mvn"
fi

# Start Spring Boot in background
$MVN_CMD spring-boot:run -q &
BACKEND_PID=$!
cd ..

echo -e "${GREEN}Backend starting on http://localhost:8080${NC}"
echo ""

# Wait for backend to be ready
echo -e "${YELLOW}Waiting for backend to be ready...${NC}"
for i in {1..60}; do
    if curl -s http://localhost:8080/api/chat/status > /dev/null 2>&1; then
        echo -e "${GREEN}Backend is ready!${NC}"
        break
    fi
    sleep 1
    echo -n "."
done
echo ""

# Start Frontend
echo -e "${BLUE}Starting Frontend Server...${NC}"
cd frontend

# Install dependencies if node_modules doesn't exist
if [ ! -d "node_modules" ]; then
    echo -e "${YELLOW}Installing frontend dependencies...${NC}"
    npm install
fi

# Start Vite dev server
npm run dev &
FRONTEND_PID=$!
cd ..

echo -e "${GREEN}Frontend starting on http://localhost:3000${NC}"
echo ""

# Print access information
echo -e "${GREEN}=======================================${NC}"
echo -e "${GREEN}  Embabel Chat is now running!        ${NC}"
echo -e "${GREEN}=======================================${NC}"
echo ""
echo -e "  Frontend: ${BLUE}http://localhost:3000${NC}"
echo -e "  Backend:  ${BLUE}http://localhost:8080${NC}"
echo -e "  API Docs: ${BLUE}http://localhost:8080/api/chat/status${NC}"
echo ""
echo -e "  ${YELLOW}Press Ctrl+C to stop both servers${NC}"
echo ""

# Wait for both processes
wait $BACKEND_PID $FRONTEND_PID
