# Embabel Chat Application

A modern AI chat application built with **Embabel 0.3.4**, **Spring Boot**, and **React**. Features multi-agent orchestration, real-time streaming, data visualization, and document Q&A with RAG.

![Embabel Chat](docs/screenshot.png)

## Features

- **Multi-Agent Orchestration**: Powered by Embabel's GOAP (Goal-Oriented Action Planning)
- **Real-time Streaming**: WebSocket-based streaming responses with visible thinking process
- **Data Visualization**: Create pie charts, bar charts, line charts, and more
- **Document Q&A**: RAG-based question answering about ingested documents
- **In-Memory Persistence**: Session and chat history with Caffeine cache
- **Vault Integration**: Secure API key management (mocked for demo)

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                        React Frontend                           │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────────────────┐  │
│  │   Sidebar   │  │  Chat Area  │  │    Thinking Panel       │  │
│  │  (Sessions) │  │  (Messages) │  │  (Agent Reasoning)      │  │
│  └─────────────┘  └─────────────┘  └─────────────────────────┘  │
└─────────────────────────────────────────────────────────────────┘
                              │
                              │ WebSocket / REST
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                    Spring Boot Backend                          │
│  ┌─────────────────────────────────────────────────────────┐    │
│  │              Embabel Agent Platform                      │    │
│  │  ┌─────────────┐  ┌─────────────┐  ┌─────────────────┐  │    │
│  │  │   Vault     │  │  Thinking   │  │    Response     │  │    │
│  │  │   Agent     │  │   Agent     │  │     Agent       │  │    │
│  │  └─────────────┘  └─────────────┘  └─────────────────┘  │    │
│  │  ┌─────────────┐  ┌─────────────┐  ┌─────────────────┐  │    │
│  │  │  Document   │  │    Data     │  │  Visualization  │  │    │
│  │  │   Agent     │  │   Agent     │  │     Agent       │  │    │
│  │  └─────────────┘  └─────────────┘  └─────────────────┘  │    │
│  └─────────────────────────────────────────────────────────┘    │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────────────────┐  │
│  │   RAG       │  │   Vault     │  │   Session Management    │  │
│  │  (Lucene)   │  │  Service    │  │   (Caffeine Cache)      │  │
│  └─────────────┘  └─────────────┘  └─────────────────────────┘  │
└─────────────────────────────────────────────────────────────────┘
```

## Prerequisites

- **Java 21** or higher
- **Maven 3.9+**
- **Node.js 18+** and **npm**
- **OpenAI API Key** (optional - demo mode works without it)

## Quick Start

### 1. Clone and Navigate

```bash
cd embabel-chat-app
```

### 2. Configure Environment (Optional)

Set your OpenAI API key (or use demo mode):

```bash
export OPENAI_API_KEY="sk-your-api-key"
```

### 3. Start the Backend

```bash
cd backend
mvn spring-boot:run
```

The backend will start on `http://localhost:8080`

### 4. Start the Frontend

In a new terminal:

```bash
cd frontend
npm install
npm run dev
```

The frontend will start on `http://localhost:3000`

### 5. Open in Browser

Navigate to `http://localhost:3000` to use the application.

## Project Structure

```
embabel-chat-app/
├── backend/
│   ├── src/main/java/com/embabel/chat/
│   │   ├── agent/              # Embabel Agents
│   │   │   ├── ChatOrchestratorAgent.java
│   │   │   ├── ThinkingPlanningAgent.java
│   │   │   ├── ResponseAgent.java
│   │   │   ├── DocumentIngestionAgent.java
│   │   │   ├── DataAnalysisAgent.java
│   │   │   └── VisualizationAgent.java
│   │   ├── config/             # Configuration
│   │   ├── controller/         # REST & WebSocket Controllers
│   │   ├── model/              # Data Models
│   │   ├── service/            # Business Services
│   │   ├── vault/              # Vault Agent & Service
│   │   └── EmbabelChatApplication.java
│   ├── src/main/resources/
│   │   └── application.yml     # Configuration
│   └── pom.xml                 # Maven dependencies
├── frontend/
│   ├── src/
│   │   ├── components/         # React Components
│   │   ├── services/           # API & WebSocket Services
│   │   ├── types/              # TypeScript Types
│   │   ├── utils/              # Utilities
│   │   ├── App.tsx
│   │   └── main.tsx
│   ├── package.json
│   └── vite.config.ts
└── README.md
```

## API Endpoints

### REST API

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/chat/sessions` | Create new session |
| GET | `/api/chat/sessions` | List user sessions |
| GET | `/api/chat/sessions/{id}` | Get session details |
| GET | `/api/chat/sessions/{id}/messages` | Get session messages |
| POST | `/api/chat/sessions/{id}/messages` | Send message |
| DELETE | `/api/chat/sessions/{id}` | Delete session |
| GET | `/api/chat/documents` | List ingested documents |
| POST | `/api/chat/documents` | Ingest document |
| GET | `/api/chat/documents/search` | Search documents |
| GET | `/api/chat/status` | System status |

### WebSocket

| Endpoint | Description |
|----------|-------------|
| `/ws/chat` | WebSocket connection |
| `/app/chat.sendMessage` | Send message |
| `/app/chat.typing` | Typing indicator |
| `/topic/chat/{id}` | Subscribe to conversation |
| `/topic/thinking/{id}` | Subscribe to thinking |

## Agents

### 1. Vault Agent
Manages API keys and secrets securely. Fetches LLM API keys at runtime from vault.

### 2. Thinking/Planning Agent
Analyzes user queries, creates execution plans, and generates thinking steps for observability.

### 3. Response Agent
Generates final responses using gathered information from other agents.

### 4. Document Ingestion Agent
Processes and ingests documents for RAG-based question answering.

### 5. Data Analysis Agent
Analyzes data and extracts insights for visualization.

### 6. Visualization Agent
Creates charts and graphs (pie, bar, line, doughnut).

### 7. Chat Orchestrator Agent
Coordinates all agents to handle chat requests.

## Configuration

### Backend (`application.yml`)

```yaml
# LLM Configuration
embabel:
  models:
    default-llm: gpt-4o-mini
    llms:
      thinking: gpt-4o
      response: gpt-4o-mini

# Session Configuration
chat:
  app:
    session:
      timeout-minutes: 60
    streaming:
      enabled: true
```

### Frontend (`.env`)

```env
VITE_API_URL=http://localhost:8080
VITE_WS_URL=ws://localhost:8080/ws
```

## Example Queries

Try these example queries to explore the application:

1. **General Questions**
   - "What is Embabel?"
   - "How does multi-agent orchestration work?"

2. **Document Q&A**
   - "What are the key features of Embabel?"
   - "Compare Embabel with Spring AI"

3. **Data Visualization**
   - "Show me a pie chart of market share"
   - "Create a bar chart of monthly sales data"
   - "Visualize performance metrics"

## Development

### Running Tests

```bash
# Backend tests
cd backend
mvn test

# Frontend tests
cd frontend
npm test
```

### Building for Production

```bash
# Build backend
cd backend
mvn clean package

# Build frontend
cd frontend
npm run build
```

### Docker (Optional)

```bash
# Build and run with Docker
docker build -t embabel-chat .
docker run -p 8080:8080 embabel-chat
```

## Technologies

### Backend
- **Embabel 0.3.4** - Agent Framework
- **Spring Boot 3.3.5** - Web Framework
- **Spring WebSocket** - Real-time Communication
- **Lucene** - Document Search & RAG
- **Caffeine** - In-Memory Caching
- **OpenAI API** - LLM Integration

### Frontend
- **React 18** - UI Framework
- **TypeScript** - Type Safety
- **Tailwind CSS** - Styling
- **Chart.js** - Data Visualization
- **STOMP.js** - WebSocket Client
- **Axios** - HTTP Client

## License

MIT License - See LICENSE file for details.

## Contributing

Contributions are welcome! Please read our [Contributing Guide](CONTRIBUTING.md) for details.

## Support

For support, please:
- Open an issue on GitHub
- Contact us at support@embabel.com
- Visit our documentation at https://docs.embabel.com

## Acknowledgments

- Built with [Embabel](https://embabel.com) - The Agent Framework for the JVM
- Inspired by modern AI chat interfaces
- Thanks to the Spring and React communities
