package com.embabel.chat.agent;

import com.embabel.agent.api.annotation.Action;
import com.embabel.agent.api.annotation.Agent;
import com.embabel.agent.api.common.OperationContext;
import com.embabel.chat.model.ChatSession;
import com.embabel.chat.model.ThinkingStep;
import com.embabel.chat.service.ChatSessionService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.*;

/**
 * Thinking and Planning Agent
 * 
 * This agent is responsible for:
 * 1. Analyzing user queries
 * 2. Planning the approach to answer
 * 3. Selecting appropriate tools and agents
 * 4. Reasoning through complex problems
 * 5. Providing thinking steps for observability
 * 
 * Uses the ReAct pattern (Reasoning + Acting) internally.
 */
@Slf4j
@Component
@RequiredArgsConstructor
@Agent(description = "Agent that analyzes queries, plans approaches, and reasons through problems")
public class ThinkingPlanningAgent {

    private final ChatSessionService sessionService;

    /**
     * Query analysis result
     */
    public record QueryAnalysis(
            String originalQuery,
            String intent,
            List<String> entities,
            List<String> keywords,
            QueryType queryType,
            double complexity,
            boolean requiresVisualization,
            boolean requiresDocumentSearch,
            List<String> requiredCapabilities
    ) {}
    
    public enum QueryType {
        GENERAL_QUESTION,   // General knowledge question
        DOCUMENT_QUERY,     // Query about ingested documents
        DATA_ANALYSIS,      // Request for data analysis
        VISUALIZATION,      // Request for chart/graph
        COMPARISON,         // Comparison between items
        CREATIVE,           // Creative writing/generation
        CODE,               // Code-related query
        CONVERSATIONAL      // Casual conversation
    }
    
    /**
     * Execution plan
     */
    public record ExecutionPlan(
            String planId,
            List<PlanStep> steps,
            String estimatedApproach,
            double confidence,
            Map<String, Object> context
    ) {}
    
    public record PlanStep(
            int order,
            String agentName,
            String action,
            String description,
            List<String> inputs,
            List<String> outputs,
            boolean parallelizable
    ) {}
    
    /**
     * Action: Analyze user query
     */
    @Action(description = "Analyze user query to understand intent and requirements")
    public QueryAnalysis analyzeQuery(String query, OperationContext context) {
        log.info("Analyzing query: {}", query);
        
        // Use LLM for sophisticated query analysis
        QueryAnalysisResult result = context.ai()
                .withLlmByRole("analysis")
                .createObject(
                        """
                        Analyze this user query and provide structured information:
                        
                        Query: "%s"
                        
                        Determine:
                        1. Primary intent (what does the user want?)
                        2. Key entities mentioned
                        3. Important keywords
                        4. Query type (general, document-related, data analysis, etc.)
                        5. Complexity (0.0-1.0)
                        6. Does it require visualization?
                        7. Does it require document search?
                        8. Required capabilities
                        """.formatted(query),
                        QueryAnalysisResult.class
                );
        
        QueryAnalysis analysis = new QueryAnalysis(
                query,
                result.intent(),
                result.entities(),
                result.keywords(),
                QueryType.valueOf(result.queryType()),
                result.complexity(),
                result.requiresVisualization(),
                result.requiresDocumentSearch(),
                result.requiredCapabilities()
        );
        
        // Add to blackboard for other agents (using correct API signature)
        // context.addObject(analysis);  // Temporarily disabled due to API mismatch

        log.info("Query analysis complete - Type: {}, Complexity: {}", 
                analysis.queryType(), analysis.complexity());
        
        return analysis;
    }
    
    /**
     * Action: Create execution plan
     */
    @Action(description = "Create execution plan based on query analysis")
    public ExecutionPlan createPlan(QueryAnalysis analysis, OperationContext context) {
        log.info("Creating execution plan for query type: {}", analysis.queryType());
        
        List<PlanStep> steps = new ArrayList<>();
        int order = 1;
        
        // Step 1: Document search if needed
        if (analysis.requiresDocumentSearch()) {
            steps.add(new PlanStep(
                    order++,
                    "DocumentIngestionAgent",
                    "searchDocuments",
                    "Search ingested documents for relevant information",
                    List.of("query"),
                    List.of("searchResults"),
                    false
            ));
        }
        
        // Step 2: Data gathering/analysis
        if (analysis.queryType() == QueryType.DATA_ANALYSIS || 
            analysis.queryType() == QueryType.COMPARISON) {
            steps.add(new PlanStep(
                    order++,
                    "DataAnalysisAgent",
                    "analyzeData",
                    "Analyze data and extract insights",
                    List.of("query", "searchResults"),
                    List.of("analysisResult"),
                    false
            ));
        }
        
        // Step 3: Visualization if needed
        if (analysis.requiresVisualization()) {
            steps.add(new PlanStep(
                    order++,
                    "VisualizationAgent",
                    "createVisualization",
                    "Create appropriate chart or graph",
                    List.of("analysisResult", "query"),
                    List.of("visualization"),
                    false
            ));
        }
        
        // Step 4: Response generation
        steps.add(new PlanStep(
                order++,
                "ResponseAgent",
                "generateResponse",
                "Generate final response to user",
                List.of("query", "searchResults", "analysisResult", "visualization"),
                List.of("response"),
                false
        ));
        
        ExecutionPlan plan = new ExecutionPlan(
                UUID.randomUUID().toString(),
                steps,
                generateApproachDescription(analysis),
                calculateConfidence(analysis, steps),
                Map.of("analysis", analysis)
        );
        
        // context.addObject(plan);  // Temporarily disabled due to API mismatch

        log.info("Execution plan created with {} steps", steps.size());
        
        return plan;
    }
    
    /**
     * Action: Search documents if needed
     */
    @Action(description = "Search ingested documents for relevant content")
    public DocumentSearchResults searchDocumentsIfNeeded(QueryAnalysis analysis, OperationContext context) {
        if (!analysis.requiresDocumentSearch()) {
            return new DocumentSearchResults(Collections.emptyList(), false);
        }
        
        log.info("Searching documents for query: {}", analysis.originalQuery());
        
        // Stub implementation - RAG library not available
        // In a full implementation, this would search through indexed documents
        List<DocumentResult> documentResults = Collections.emptyList();

        log.info("Found {} relevant document chunks", documentResults.size());
        
        return new DocumentSearchResults(documentResults, !documentResults.isEmpty());
    }
    
    /**
     * Action: Generate thinking steps for observability
     */
    @Action(description = "Generate thinking steps to show reasoning process")
    public ThinkingProcess generateThinkingSteps(
            QueryAnalysis analysis,
            ExecutionPlan plan,
            OperationContext context) {
        
        log.info("Generating thinking steps for observability");
        
        List<ThinkingStep> steps = new ArrayList<>();
        
        // Step 1: Analysis
        ThinkingStep analysisStep = ThinkingStep.create(
                ThinkingStep.StepType.ANALYSIS,
                "Analyzing your question",
                "Understanding what you're asking for",
                1
        );
        analysisStep.addReasoning("Identified intent: " + analysis.intent());
        analysisStep.addReasoning("Query type: " + analysis.queryType());
        analysisStep.addReasoning("Complexity: " + String.format("%.2f", analysis.complexity()));
        analysisStep.complete();
        steps.add(analysisStep);
        
        // Step 2: Planning
        ThinkingStep planningStep = ThinkingStep.create(
                ThinkingStep.StepType.PLANNING,
                "Planning the approach",
                "Deciding how to best answer your question",
                2
        );
        planningStep.addReasoning("Approach: " + plan.estimatedApproach());
        planningStep.addReasoning("Steps: " + plan.steps().size());
        for (PlanStep step : plan.steps()) {
            planningStep.addReasoning("  - " + step.order() + ". " + step.description());
        }
        planningStep.complete();
        steps.add(planningStep);
        
        // Step 3: Research (if document search needed)
        if (analysis.requiresDocumentSearch()) {
            ThinkingStep researchStep = ThinkingStep.create(
                    ThinkingStep.StepType.RESEARCH,
                    "Searching documents",
                    "Looking for relevant information in ingested documents",
                    3
            );
            researchStep.addReasoning("Searching for: " + String.join(", ", analysis.keywords()));
            researchStep.complete();
            steps.add(researchStep);
        }
        
        // Step 4: Tool Selection
        ThinkingStep toolStep = ThinkingStep.create(
                ThinkingStep.StepType.TOOL_SELECTION,
                "Selecting tools",
                "Choosing the right tools for this task",
                steps.size() + 1
        );
        for (String capability : analysis.requiredCapabilities()) {
            toolStep.addReasoning("Will use: " + capability);
        }
        toolStep.complete();
        steps.add(toolStep);
        
        return new ThinkingProcess(
                UUID.randomUUID().toString(),
                steps,
                plan.confidence(),
                Instant.now()
        );
    }
    
    // Supporting records
    public record QueryAnalysisResult(
            String intent,
            List<String> entities,
            List<String> keywords,
            String queryType,
            double complexity,
            boolean requiresVisualization,
            boolean requiresDocumentSearch,
            List<String> requiredCapabilities
    ) {}
    
    public record DocumentSearchResults(
            List<DocumentResult> results,
            boolean hasResults
    ) {}
    
    public record DocumentResult(
            String documentId,
            String content,
            double score,
            Map<String, Object> metadata
    ) {}
    
    public record ThinkingProcess(
            String processId,
            List<ThinkingStep> steps,
            double overallConfidence,
            Instant generatedAt
    ) {}
    
    // Helper methods
    private String generateApproachDescription(QueryAnalysis analysis) {
        return switch (analysis.queryType()) {
            case DOCUMENT_QUERY -> "Search documents and synthesize answer from relevant content";
            case DATA_ANALYSIS -> "Analyze data patterns and provide insights";
            case VISUALIZATION -> "Create visualization to represent data clearly";
            case COMPARISON -> "Compare items across multiple dimensions";
            case CODE -> "Provide code explanation or generation";
            case CREATIVE -> "Generate creative content";
            default -> "Provide direct answer based on knowledge";
        };
    }
    
    private double calculateConfidence(QueryAnalysis analysis, List<PlanStep> steps) {
        double baseConfidence = 0.8;
        
        // Adjust based on complexity
        baseConfidence -= analysis.complexity() * 0.2;
        
        // Adjust based on available steps
        if (steps.isEmpty()) {
            baseConfidence -= 0.2;
        }
        
        // Adjust based on query type
        if (analysis.queryType() == QueryType.GENERAL_QUESTION) {
            baseConfidence += 0.1;
        }
        
        return Math.max(0.0, Math.min(1.0, baseConfidence));
    }
}
