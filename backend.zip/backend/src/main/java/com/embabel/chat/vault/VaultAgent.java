package com.embabel.chat.vault;

import com.embabel.agent.api.annotation.Action;
import com.embabel.agent.api.annotation.Agent;
import com.embabel.agent.api.common.OperationContext;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * Vault Agent
 * 
 * An Embabel agent responsible for securely managing and providing API keys
 * and other secrets to other agents in the system.
 * 
 * This agent demonstrates:
 * - Integration with external secret management systems
 * - Secure credential handling
 * - Runtime configuration retrieval
 */
@Slf4j
@Component
@RequiredArgsConstructor
@Agent(description = "Agent responsible for securely managing API keys and secrets from vault")
public class VaultAgent {

    private final VaultService vaultService;
    
    /**
     * API Key Request/Response records
     */
    public record ApiKeyRequest(String provider, String purpose) {}
    public record ApiKeyResponse(String provider, String key, boolean success, String message) {}
    public record ApiKeysBundle(
            String openAiKey,
            String anthropicKey,
            String googleKey,
            Map<String, String> metadata
    ) {}
    
    /**
     * Action: Retrieve a specific API key
     */
    @Action(description = "Retrieve API key for specified provider from vault")
    public ApiKeyResponse getApiKey(ApiKeyRequest request, OperationContext context) {
        log.info("Retrieving API key for provider: {}", request.provider());
        
        String key = switch (request.provider().toLowerCase()) {
            case "openai" -> vaultService.getOpenAiApiKey();
            case "anthropic" -> vaultService.getAnthropicApiKey();
            case "google", "gemini" -> vaultService.getGoogleApiKey();
            default -> vaultService.getSecret("llm/" + request.provider() + "/api-key");
        };
        
        if (key == null) {
            return new ApiKeyResponse(
                    request.provider(),
                    null,
                    false,
                    "API key not found for provider: " + request.provider()
            );
        }
        
        // Log the access (not the key itself)
        Map<String, Object> accessLog = Map.of(
                "provider", request.provider(),
                "purpose", request.purpose(),
                "timestamp", java.time.Instant.now()
        );
        // context.addObject(accessLog);  // Temporarily disabled due to API mismatch

        return new ApiKeyResponse(
                request.provider(),
                key,
                true,
                "API key retrieved successfully"
        );
    }
    
    /**
     * Action: Retrieve all API keys as a bundle
     */
    @Action(description = "Retrieve all configured API keys from vault")
    public ApiKeysBundle getAllApiKeys(OperationContext context) {
        log.info("Retrieving all API keys from vault");
        
        String openAiKey = vaultService.getOpenAiApiKey();
        String anthropicKey = vaultService.getAnthropicApiKey();
        String googleKey = vaultService.getGoogleApiKey();
        
        // Log access
        Map<String, Object> accessLog = Map.of(
                "timestamp", java.time.Instant.now(),
                "providers", "openai,anthropic,google"
        );
        // context.addObject(accessLog);  // Temporarily disabled due to API mismatch

        return new ApiKeysBundle(
                openAiKey,
                anthropicKey,
                googleKey,
                Map.of(
                        "source", "vault",
                        "mode", vaultService.getVaultStatus().get("mockMode") != null ? 
                                vaultService.getVaultStatus().get("mockMode").toString() : "unknown"
                )
        );
    }
    
    /**
     * Action: Validate API key
     */
    @Action(description = "Validate that an API key is properly configured")
    public boolean validateApiKey(String provider, OperationContext context) {
        String key = switch (provider.toLowerCase()) {
            case "openai" -> vaultService.getOpenAiApiKey();
            case "anthropic" -> vaultService.getAnthropicApiKey();
            case "google", "gemini" -> vaultService.getGoogleApiKey();
            default -> vaultService.getSecret("llm/" + provider + "/api-key");
        };
        
        boolean isValid = key != null && !key.isEmpty() && !key.contains("demo");
        
        log.info("API key validation for {}: {}", provider, isValid ? "valid" : "invalid/demo");
        
        return isValid;
    }
    
    /**
     * Action: Get vault status
     */
    @Action(description = "Get current vault status and configuration")
    public Map<String, Object> getVaultStatus(OperationContext context) {
        return vaultService.getVaultStatus();
    }
}
